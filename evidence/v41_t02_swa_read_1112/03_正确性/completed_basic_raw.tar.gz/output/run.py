import pathlib,subprocess,os,json,datetime
r=pathlib.Path('/work');o=r/'new_start_t02_swa_read_probe_v1';env=dict(os.environ);env.update(MUSA_VISIBLE_DEVICES='0',LD_PRELOAD='',PYTHONPATH='/work/artifacts/native_t02_swa_read/lib:/work/repos/xllm-musa',TVM_FFI_GPU_BACKEND='musa');env['LD_LIBRARY_PATH']='/work/artifacts/native_t02_swa_read/lib:'+env.get('LD_LIBRARY_PATH','')
cfg=json.loads((r/'runs/t02_prefill_ffi_sync_v1/sj10/role_config.json').read_text());sparse=cfg['ranks'][0]['environment']['XLLM_DSV41_MATE_SPARSE_SO']
cmd=['python3',str(o/'validate.py'),'--output',str(o/'checks.json'),'--sparse-library',sparse]
with (o/'probe.log').open('w') as log:rc=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
(o/'result.json').write_text(json.dumps({'exit_code':rc,'finished_at':datetime.datetime.now().astimezone().isoformat(),'automatic_kill':False}));raise SystemExit(rc)
