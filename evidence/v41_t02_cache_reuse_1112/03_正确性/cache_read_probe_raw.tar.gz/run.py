import os,subprocess,pathlib,json,datetime,sys
r=pathlib.Path('/work');o=r/'new_start_t02_cache_read_probe_v1';env=dict(os.environ);env['LD_PRELOAD']='';env['PYTHONPATH']='/work/artifacts/native_t02_cache_read/lib:/work/repos/xllm-musa';env['LD_LIBRARY_PATH']='/work/artifacts/native_t02_cache_read/lib:'+env.get('LD_LIBRARY_PATH','');env['MUSA_VISIBLE_DEVICES']='0'
cmd=[sys.executable,str(o/'validate.py'),'--output',str(o/'checks.json')]
with (o/'probe.log').open('w') as log:
 p=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT);(o/'launch.json').write_text(json.dumps({'pid':p.pid,'command':cmd,'env_overrides':{k:env[k] for k in ['LD_PRELOAD','PYTHONPATH','MUSA_VISIBLE_DEVICES']},'started_at':datetime.datetime.now().astimezone().isoformat()}));rc=p.wait()
(o/'result.json').write_text(json.dumps({'exit_code':rc,'finished_at':datetime.datetime.now().astimezone().isoformat(),'no_signals':True}));raise SystemExit(rc)
