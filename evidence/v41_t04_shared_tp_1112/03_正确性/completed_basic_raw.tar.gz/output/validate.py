"""Offline eight-rank probe: shared-expert TP slicing and one combined FP32 reduction."""
from __future__ import annotations
import argparse
import datetime
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time


def _worker(rank: int, host: str, port: int, out: Path) -> None:
    import torch
    import torch_musa
    import torch.distributed as dist
    import musa_python_kernel_test_module
    torch.set_num_threads(1)
    torch.musa.set_device(rank)
    store=dist.TCPStore(host,port,8,rank==0,datetime.timedelta(seconds=90))
    dist.init_process_group('mccl',store=dist.PrefixStore('mccl/',store),rank=rank,world_size=8,timeout=datetime.timedelta(seconds=30))
    ops=torch.ops._C_custom_ar
    local_allocations=[]
    def share(size: int, label: str) -> list[int]:
        pointer,handle=ops.allocate_shared_buffer_and_handle(size)
        local_allocations.append(pointer)
        keys=[label+'/'+str(i) for i in range(8)]
        store.set(keys[rank],handle.cpu().numpy().tobytes())
        store.wait(keys)
        return [pointer if i==rank else ops.open_mem_handle(torch.tensor(list(store.get(keys[i])),dtype=torch.uint8)) for i in range(8)]
    max_bytes=8*1024*1024
    meta=share(ops.meta_size()+max_bytes,'meta')
    buffers=share(max_bytes,'buffer')
    rank_data=torch.empty(8*1024*1024,device='musa:'+str(rank),dtype=torch.uint8)
    handle=ops.init_custom_ar(meta,rank_data,rank,True)
    ops.set_algorithm(handle,1)
    ops.register_buffer(handle,buffers)
    def vote(label: str, valid: bool) -> None:
        keys=[label+'/'+str(i) for i in range(8)];store.set(keys[rank],b'1' if valid else b'0');store.wait(keys)
        if any(store.get(k)!=b'1' for k in keys):raise AssertionError('Synchronized numerical/capability failure: '+label)
    vote('initialized',True)
    result={'rank':rank,'device':rank,'world_size':8,'group':'tp_group algorithm1 / native dispatcher','model_width':5120,'results':[],'numeric':[],'interpretation':'All-ready API/stream latency probe; Python enqueue overhead remains, not pure wire time and not full-model performance.'}
    with torch.inference_mode():
        import musa_python_kernel_test_module as native
        torch.manual_seed(111204)
        hidden,intermediate=5120,2048
        cpu_weights=[(torch.randn(intermediate,hidden)*0.02).to(torch.bfloat16),
                     (torch.randn(intermediate,hidden)*0.02).to(torch.bfloat16),
                     (torch.randn(hidden,intermediate)*0.02).to(torch.bfloat16)]
        weights=[x.to('musa:'+str(rank)) for x in cpu_weights]
        full=native.NativeV41SharedMlp(*weights,10.0,True)
        local_width=intermediate//8
        local=native.NativeV41SharedMlp(weights[0][rank*local_width:(rank+1)*local_width].contiguous(),
                                        weights[1][rank*local_width:(rank+1)*local_width].contiguous(),
                                        weights[2][:,rank*local_width:(rank+1)*local_width].contiguous(),10.0,True)
        result['purpose']='Three q1 cases, original block32 QDQ and SwiGLU, TP8 shared slices, one custom FP32 sum including local routed contribution'
        result['cases']=[]
        for index,magnitude in enumerate([0.0,1.0,50.0]):
            value=(torch.randn(1,hidden)*magnitude).to(torch.bfloat16).to('musa:'+str(rank))
            expected=full.forward(value).float()
            partial=local.forward(value).float()
            reduced=torch.empty_like(partial)
            ops.all_reduce(handle,partial,reduced,buffers[rank],max_bytes)
            # BF16 partial down projections round before the FP32 sum, while
            # the reference rounds its full projection once. Bound that local
            # operator rounding, without requiring full-model answer equality.
            difference=reduced-expected
            rms=float((difference.square().mean().sqrt()/expected.square().mean().sqrt().clamp_min(1e-5)).item())
            max_abs=float(difference.abs().max().item())
            print(json.dumps({'rank':rank,'case':index,'shared_relative_rms':rms,'shared_max_abs':max_abs}),flush=True)
            vote('shared_case_'+str(index),rms<=0.02)
            routed_base=(torch.arange(hidden,device=value.device,dtype=torch.float32).remainder(17)-8).reshape(1,hidden)*0.001
            local_combined=partial+routed_base*(rank+1)
            combined=torch.empty_like(local_combined)
            ops.all_reduce(handle,local_combined,combined,buffers[rank],max_bytes)
            residual_error=float((combined-reduced-routed_base*36).abs().max().item())
            tolerance=16*torch.finfo(torch.float32).eps*max(1,float(reduced.abs().max().item()),float(combined.abs().max().item()))
            print(json.dumps({'rank':rank,'case':index,'combined_contribution_error':residual_error,'tolerance':tolerance}),flush=True)
            vote('one_combined_sum_'+str(index),residual_error<=tolerance)
            result['cases'].append({'magnitude':magnitude,'shared_relative_rms':rms,'shared_max_abs':max_abs,'combined_contribution_max_abs':residual_error,'combined_tolerance':tolerance,'shared_added_once':True,'local_intermediate':local_width,'block32_aligned':local_width%32==0})
        torch.musa.synchronize()
    vote('all_gpu_work_done',True)
    ops.dispose(handle)
    # Everyone has finished GPU work before any local IPC allocation is freed.
    vote('all_handles_disposed',True)
    for ptr in local_allocations:ops.free_shared_buffer(ptr)
    dist.destroy_process_group()
    (out/('rank'+str(rank)+'.json')).write_text(json.dumps(result,indent=2))


def main() -> None:
    parser=argparse.ArgumentParser();parser.add_argument('--rank',type=int);parser.add_argument('--host',required=True);parser.add_argument('--port',type=int,default=22551);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    if args.rank is not None:
        _worker(args.rank,args.host,args.port,args.output);return
    args.output.mkdir(parents=True,exist_ok=False)
    children=[];logs=[]
    for rank in range(8):
        log=(args.output/('rank'+str(rank)+'.log')).open('wb');logs.append(log)
        children.append(subprocess.Popen([sys.executable,__file__,'--rank',str(rank),'--host',args.host,'--port',str(args.port),'--output',str(args.output)],stdout=log,stderr=subprocess.STDOUT))
    (args.output/'launch.json').write_text(json.dumps({'pids':[p.pid for p in children],'started_at':datetime.datetime.now().astimezone().isoformat(),'note':'Only this exact owned-container eight-process probe; no SIGKILL/restart.'},indent=2))
    term_sent=False;deadline=time.monotonic()+300
    while any(p.poll() is None for p in children):
        if not term_sent and (any(p.poll() not in [None,0] for p in children) or time.monotonic()>deadline):
            for p in children:
                if p.poll() is None:p.terminate()
            term_sent=True
        (args.output/'status.json').write_text(json.dumps({'pids':[p.pid for p in children],'exit_codes':[p.poll() for p in children],'TERM_sent':term_sent}))
        time.sleep(1)
    codes=[p.returncode for p in children]
    for log in logs:log.close()
    result={'exit_codes':codes,'TERM_sent':term_sent,'SIGKILL_sent':False,'finished_at':datetime.datetime.now().astimezone().isoformat()}
    (args.output/'result.json').write_text(json.dumps(result,indent=2))
    if codes!=[0]*8:raise RuntimeError(result)


if __name__=='__main__':main()
