import os,subprocess,pathlib,json,datetime,sys,hashlib
r=pathlib.Path('/work');o=r/'new_start_t04_shared_tp_probe_v1';env=dict(os.environ);env['LD_PRELOAD']='';env['PYTHONPATH']='/work/artifacts/native_t04_shared_tp/lib:/work/repos/xllm-musa';env['LD_LIBRARY_PATH']='/work/artifacts/native_t04_shared_tp/lib:'+env.get('LD_LIBRARY_PATH','');env['TVM_FFI_GPU_BACKEND']='musa'
cmd=[sys.executable,str(o/'validate.py'),'--host','10.121.32.9','--port','22551','--output',str(o/'ranks')]
with (o/'probe.log').open('w') as log:
 p=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT);(o/'launch.json').write_text(json.dumps({'pid':p.pid,'command':cmd,'source_sha256':hashlib.sha256((o/'validate.py').read_bytes()).hexdigest(),'started_at':datetime.datetime.now().astimezone().isoformat()}));rc=p.wait()
(o/'result.json').write_text(json.dumps({'exit_code':rc,'finished_at':datetime.datetime.now().astimezone().isoformat(),'SIGKILL_sent':False}));raise SystemExit(rc)
