import torch,torch_musa,json,inspect
before=getattr(torch.musa,'is_initialized',lambda:'unavailable')()
import deep_ep_cpp,deep_ep
out={'torch':torch.__version__,'torch_musa':torch_musa.__version__,'extension':deep_ep_cpp.__file__,'package':deep_ep.__file__,'gpu_initialized_before':before,'gpu_initialized_after':getattr(torch.musa,'is_initialized',lambda:'unavailable')(),'buffer_instantiated':False,'api_docs':{}}
for n in ['__init__','low_latency_dispatch','low_latency_combine','get_local_ipc_handle','sync']:
 out['api_docs'][n]=getattr(deep_ep_cpp.Buffer,n).__doc__
print(json.dumps(out))
