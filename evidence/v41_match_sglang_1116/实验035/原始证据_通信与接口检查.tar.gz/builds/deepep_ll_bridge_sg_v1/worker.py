from pathlib import Path
import os,sys,json,subprocess,datetime,hashlib,resource
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
import torch,torch_musa
from torch.utils.cpp_extension import include_paths,library_paths
r=Path('/expt/builds/deepep_ll_bridge_sg_v1');out=r/'v41_deep_ep_ll_bridge_test_module.so'
cmd=['c++','-O2','-g0','-shared','-fPIC','-std=c++17','-D_GLIBCXX_USE_CXX11_ABI='+str(int(torch._C._GLIBCXX_USE_CXX11_ABI)),'-I'+str(r/'xllm'),'-I/usr/include/python3.10']+['-I'+x for x in include_paths()]+[str(r/'tests/core/kernels/musa/v41_deep_ep_ll_bridge_test_module.cpp')]+['-L'+x for x in library_paths()]+['-Wl,-rpath,'+x for x in library_paths()]+['-ltorch','-ltorch_cpu','-ltorch_python','-lc10','-lglog','-o',str(out)]
(r/'command.json').write_text(json.dumps(cmd,indent=2));p=subprocess.run(cmd,stdout=sys.stdout,stderr=sys.stderr);v={'exit_code':p.returncode,'at':datetime.datetime.now().astimezone().isoformat(),'torch':torch.__version__,'torch_musa':torch_musa.__version__}
if p.returncode==0:v.update(binary=str(out),sha256=hashlib.sha256(out.read_bytes()).hexdigest(),bytes=out.stat().st_size)
(r/'finished.json').write_text(json.dumps(v,indent=2))
