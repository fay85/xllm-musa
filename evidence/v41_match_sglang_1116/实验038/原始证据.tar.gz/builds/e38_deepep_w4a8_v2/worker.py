from pathlib import Path
import subprocess,json,shlex,os,datetime,hashlib
r=Path('/expt/builds/e38_deepep_w4a8_v2');s=Path('/workspace/xllm-mt-main');b=s/'build/cmake.linux-x86_64-cpython-310';rc=1
base=Path('/expt/builds/native_sg438_control');commands=[]
env=dict(os.environ,LD_LIBRARY_PATH='/expt/artifacts/native_sg438_control_v1/lib/runtime:/opt/venv/lib/python3.10/site-packages/torch_musa/lib:/opt/venv/lib/python3.10/site-packages/torch/lib:/opt/venv/lib/python3.10/site-packages/tvm_ffi/lib:/usr/local/musa/lib',LD_PRELOAD='',PYTHONPATH=str(r),MUSA_VISIBLE_DEVICES='-1')
env.update(MUSAMAPPING_PATH='/usr/local/musa/tools/musamapping',MUSA_HOME='/usr/local/musa',CUDA_HOME='/usr/local/musa',PATH=str(b/'musa_link_wrapper')+':/opt/venv/bin:/usr/local/musa/bin:/usr/bin:/bin',TVM_FFI_LIB_DIR='/opt/venv/lib/python3.10/site-packages/tvm_ffi/lib',LIBRARY_PATH=str(b/'xllm/core/layers/musa')+':/usr/local/musa/lib:/opt/intel/oneapi/mkl/lib/intel64')
try:
 cu=shlex.split((r/'cuda_command.txt').read_text().strip().splitlines()[-1]);cu[cu.index('-o')+1]=str(r/'w4a8.o')
 for flag in ['-MF','-MT']:
  if flag in cu:cu[cu.index(flag)+1]=str(r/('w4a8.d' if flag=='-MF' else 'w4a8.o'))
 commands.append(cu)
 with (r/'cuda.log').open('wb') as f:p=subprocess.run(cu,cwd=b,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==0,'CUDA compile failed'
 raw=json.loads((base/'graph_check/command.json').read_text());cpp=[x for x in raw[:raw.index(str(base/'graph_check/module.cpp'))] if x!='-shared'];cpp+=['-c',str(s/'tests/core/kernels/musa/v41_deep_ep_w4a8_test_module.cpp'),'-o',str(r/'module.o')];commands.append(cpp)
 with (r/'cpp.log').open('wb') as f:p=subprocess.run(cpp,cwd=b,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==0,'C++ compile failed'
 cmd=json.loads((base/'native_checks_v8/link_command.json').read_text());cmd[cmd.index('-o')+1]=str(r/'v41_deep_ep_w4a8_test_module.so');cmd=[str(r/'module.o') if x.endswith('/test_module.o') else x for x in cmd];cmd.insert(cmd.index('-Wl,--start-group'),str(r/'w4a8.o'));commands.append(cmd)
 with (r/'link.log').open('wb') as f:p=subprocess.run(cmd,cwd=b,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==0,'Link failed'
 p=subprocess.run(['/opt/venv/bin/python3','-c','import torch,torch_musa;import v41_deep_ep_w4a8_test_module;print("IMPORT_PASS")'],env=env,capture_output=True,text=True);(r/'import.log').write_text(p.stdout+p.stderr);assert p.returncode==0,'CPU import failed';rc=0
finally:
 (r/'commands.json').write_text(json.dumps(commands,indent=2));v={'exit_code':rc,'at':datetime.datetime.now().astimezone().isoformat()};p=r/'v41_deep_ep_w4a8_test_module.so'
 if p.exists():v.update(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)
 (r/'finished.json').write_text(json.dumps(v))
