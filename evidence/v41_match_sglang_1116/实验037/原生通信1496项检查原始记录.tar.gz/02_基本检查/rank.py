from pathlib import Path
import os,json,datetime,time,resource,sys,gc
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
import torch,torch_musa
import torch.distributed as dist
sys.path.insert(0,'/expt/builds/native_sg438_control/e37_native_mccl')
from v41_native_collective_test_module import NativeCollectives
rank=int(os.environ['RANK']);torch.musa.set_device(rank)
dist.init_process_group('mccl',init_method='tcp://127.0.0.1:35672',rank=rank,world_size=8,timeout=datetime.timedelta(seconds=90))
comm=NativeCollectives(rank,8,35671,rank);stream=torch.musa.Stream();checks=0;records=[]
with torch.musa.stream(stream):
 for dtype in [torch.bfloat16,torch.float16,torch.float32,torch.int32,torch.int64]:
  for rows in [1,4,6]:
   x=torch.full((rows,32),rank+1,device='musa',dtype=dtype)
   scatter=torch.empty((8,rows,32),device='musa',dtype=dtype)
   for i in range(8):scatter[i].fill_(rank+1+i)
   reduced=x.clone();bcast=x.clone();out=torch.empty_like(x)
   def ops():
    global gathered
    reduced.copy_(x);comm.allreduce(reduced)
    gathered=comm.allgather(x)
    bcast.copy_(x);comm.broadcast(bcast,3)
    comm.reduce_scatter(scatter,out)
   ops();stream.synchronize()
   graph=torch.musa.MUSAGraph()
   with torch.musa.graph(graph,stream=stream,capture_error_mode='thread_local'):
    ops();time.sleep(0.15)
   for step in range(3):
    x.fill_(rank+1+step)
    for i in range(8):scatter[i].fill_(rank+1+i+step)
    graph.replay();stream.synchronize()
    assert torch.equal(reduced.cpu(),torch.full((rows,32),36+8*step,dtype=dtype));checks+=1
    expected=torch.stack([torch.full((rows,32),i+1+step,dtype=dtype) for i in range(8)])
    assert torch.equal(gathered.cpu(),expected);checks+=1
    assert torch.equal(bcast.cpu(),torch.full((rows,32),4+step,dtype=dtype));checks+=1
    assert torch.equal(out.cpu(),torch.full((rows,32),36+8*(rank+step),dtype=dtype));checks+=1
   graph.reset();del graph;records.append({'dtype':str(dtype),'rows':rows,'checks':12})
 # Noncontiguous gather and all-empty ranks, graph lifetime independent of input values.
 x=torch.arange(32,device='musa',dtype=torch.float32).reshape(4,8).T+rank
 gathered=comm.allgather(x);stream.synchronize()
 expected=torch.stack([torch.arange(32,dtype=torch.float32).reshape(4,8).T+i for i in range(8)])
 assert torch.equal(gathered.cpu(),expected);checks+=1
 empty=torch.empty((0,32),device='musa');comm.allreduce(empty);g=comm.allgather(empty);comm.broadcast(empty,0);comm.reduce_scatter(empty,empty);assert g.shape==(8,0,32);checks+=1
 x=torch.full((4,5120),rank+1.,device='musa');y=x.clone();comm.allreduce(y);stream.synchronize()
 graph=torch.musa.MUSAGraph()
 with torch.musa.graph(graph,stream=stream,capture_error_mode='thread_local'):
  for _ in range(16):y=x.clone();comm.allreduce(y)
  time.sleep(2)
 for step in range(5):
  x.fill_(step+1. if rank==0 else 0.);graph.replay();stream.synchronize();assert torch.equal(y.cpu(),torch.full((4,5120),step+1.));checks+=1
 graph.reset();del graph
stream.synchronize();torch.musa.synchronize();comm.close();dist.destroy_process_group()
Path('/expt/diagnostics/e37_native_sync_mccl/runtime_v1',f'rank{rank}.json').write_text(json.dumps({'rank':rank,'checks':checks,'cases':records,'graph_capture_delayed_seconds':2,'native_cpp_helper':True,'idle_torch_mccl_watchdog_enabled':True,'pass':True}))
