from pathlib import Path
import os,json,subprocess,datetime
r=Path('/expt/diagnostics/e37_native_sync_mccl/runtime_v1');children=[];logs=[];ids=[]
env=dict(os.environ,LD_PRELOAD='',MUSA_VISIBLE_DEVICES='0,1,2,3,4,5,6,7',TORCH_MCCL_DESYNC_DEBUG='1',TORCH_MCCL_ENABLE_TIMING='1',TORCH_MCCL_ASYNC_ERROR_HANDLING='3',TORCH_MCCL_TRACE_BUFFER_SIZE='65536',TORCH_MCCL_DUMP_ON_TIMEOUT='1',OMP_NUM_THREADS='2')
for rank in range(8):
 f=(r/f'rank{rank}.log').open('wb');logs.append(f);p=subprocess.Popen(['python3',str(r/'rank.py')],env=dict(env,RANK=str(rank)),stdout=f,stderr=subprocess.STDOUT);children.append(p);ids.append({'rank':rank,'pid':p.pid,'start_ticks':Path('/proc',str(p.pid),'stat').read_text().split()[21]})
(r/'ranks.json').write_text(json.dumps(ids,indent=2));rc=[p.wait() for p in children];(r/'finished.json').write_text(json.dumps({'exit_codes':rc,'all_pass':rc==[0]*8,'at':datetime.datetime.now().astimezone().isoformat()}))
