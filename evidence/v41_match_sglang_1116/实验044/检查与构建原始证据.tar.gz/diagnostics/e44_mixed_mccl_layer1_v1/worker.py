from pathlib import Path
import os,json,subprocess,time,datetime,resource,hashlib
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
r=Path('/expt/diagnostics/e44_mixed_mccl_layer1_v1');b=Path('/expt/builds/e44_mixed_mccl_module_v2');cfg=json.loads(Path('/expt/runs/p34_verify_swa_read_on_v1/sj9/role_config.json').read_text());env=dict(os.environ,**cfg['ranks'][0]['environment']);env.update(LD_PRELOAD='',MUSA_VISIBLE_DEVICES='0,1,2,3,4,5,6,7',MASTER_ADDR='127.0.0.1',MASTER_PORT='35689',WORLD_SIZE='8',OMP_NUM_THREADS='1',XLLM_V41_LIGHT_TIMING='0')
env['LD_LIBRARY_PATH']='/expt/artifacts/native_sg438_control_v1/lib/runtime:/usr/local/mtshmem/lib:/opt/venv/lib/python3.10/site-packages/torch_musa/lib:/opt/venv/lib/python3.10/site-packages/torch/lib:/opt/venv/lib/python3.10/site-packages/tvm_ffi/lib:/usr/local/musa/lib:/usr/lib/x86_64-linux-gnu';env['PATH']='/opt/venv/bin:/usr/local/musa/bin:/usr/bin:/bin';env['PYTHONPATH']='/expt/dependencies/deepep_sg_b_090e0fe2';env['GLOO_SOCKET_IFNAME']='lo';env['XLLM_TILELANG_LIB']='/opt/venv/lib/python3.10/site-packages/tilelang/lib/libtilelang.so';env['LD_LIBRARY_PATH']='/opt/venv/lib/python3.10/site-packages/tilelang/lib:'+env['LD_LIBRARY_PATH']
(r/'environment.json').write_text(json.dumps({k:v for k,v in env.items() if k.startswith(('XLLM','MUSA','NVSHMEM','MCCL')) or k in ['LD_LIBRARY_PATH','PYTHONPATH','GLOO_SOCKET_IFNAME','MASTER_PORT']},indent=2));children=[];ids=[];streams=[]
for rank in range(8):
 f=(r/f'rank{rank}.log').open('xb');streams.append(f);e=dict(env,RANK=str(rank),LOCAL_RANK=str(rank));cmd=['/opt/venv/bin/python3','/expt/builds/e44_mixed_mccl_module_v2/src/tools/musa_deepseek_v41/validate_deepep_w4a8_chain.py','--output',str(r/'results'),'--module',str(b),'--model','/weights/DeepSeek-V4.1-Flash-1017-W4AFP8-mt','--gemm','/expt/builds/e38_static_mate_v1/lib/libdeepseek_v41_w4a8_static.so','--layers','1','--mccl-port','35691'];p=subprocess.Popen(cmd,env=e,stdout=f,stderr=subprocess.STDOUT);children.append(p);proc=Path('/proc',str(p.pid));exe=(proc/'exe').resolve();ids.append({'rank':rank,'pid':p.pid,'start_ticks':(proc/'stat').read_text().split()[21],'exe':str(exe),'exe_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'cgroup':(proc/'cgroup').read_text()})
(r/'ranks.json').write_text(json.dumps(ids,indent=2));start=time.monotonic();requested=False;term_at=0
while any(p.poll() is None for p in children):
 codes=[p.poll() for p in children];(r/'status.json').write_text(json.dumps({'at':datetime.datetime.now().astimezone().isoformat(),'exit_codes':codes,'pids':[p.pid for p in children]},indent=2))
 if (any(x is not None and x!=0 for x in codes) or time.monotonic()-start>60) and not requested:
  receipt=[]
  for ident,p in zip(ids,children):
   proc=Path('/proc',str(p.pid))
   if p.poll() is None and proc.exists() and (proc/'stat').read_text().split()[21]==ident['start_ticks']:
    assert (proc/'cgroup').read_text()==ident['cgroup'];assert str((proc/'exe').resolve())==ident['exe'];assert hashlib.sha256((proc/'exe').read_bytes()).hexdigest()==ident['exe_sha256'];assert '/expt/builds/e44_mixed_mccl_module_v2/src/tools/musa_deepseek_v41/validate_deepep_w4a8_chain.py'.encode() in (proc/'cmdline').read_bytes();p.terminate();receipt.append(ident)
  (r/'term_once.json').write_text(json.dumps(receipt,indent=2));requested=True;term_at=time.monotonic()
 if requested and time.monotonic()-term_at>130:
  (r/'cleanup_pending.json').write_text(json.dumps({'exit_codes':[p.poll() for p in children],'scope':'not terminal: fresh host ownership/thread-state verification required before any SIGKILL'}));break
 time.sleep(2)
for f in streams:f.close()
codes=[p.poll() for p in children]
if all(x is not None for x in codes):(r/'finished.json').write_text(json.dumps({'at':datetime.datetime.now().astimezone().isoformat(),'exit_codes':codes,'all_pass':all(x==0 for x in codes),'normal_term_requested':requested},indent=2))
