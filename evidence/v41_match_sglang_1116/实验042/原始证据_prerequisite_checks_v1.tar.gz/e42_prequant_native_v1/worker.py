from pathlib import Path
import os,json,subprocess,datetime,hashlib
r=Path('/expt/builds/e42_prequant_native_v1');commands=json.loads((r/'commands.json').read_text());rc=1
try:
 for i,cmd in enumerate(commands):
  with (r/(str(i)+'.log')).open('xb') as f:
   p=subprocess.Popen(cmd,cwd='/workspace/xllm-mt-main/build/cmake.linux-x86_64-cpython-310',stdout=f,stderr=subprocess.STDOUT);(r/'child.json').write_text(json.dumps({'pid':p.pid,'start_ticks':Path('/proc',str(p.pid),'stat').read_text().split()[21]}));code=p.wait()
  assert code==0,(i,code)
 p=subprocess.run(['/opt/venv/bin/python3','-c','import torch,torch_musa;import v41_prequant_projection_test_module;print("IMPORT_PASS")'],capture_output=True,text=True,env=dict(os.environ,PYTHONPATH=str(r)));(r/'import.log').write_text(p.stdout+p.stderr);assert p.returncode==0;rc=0
finally:
 z={'exit_code':rc,'at':datetime.datetime.now().astimezone().isoformat(),'unchanged_aot_launcher_object':'/expt/builds/e40_prequant_native_v1/1.o'};p=r/'v41_prequant_projection_test_module.so'
 if p.exists():z.update(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 (r/'finished.json').write_text(json.dumps(z,indent=2))
