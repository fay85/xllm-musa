from pathlib import Path
import subprocess,json,datetime
r=Path('/expt/builds/e40_prequant_aot_v2');cmd=json.loads((r/'manifest.json').read_text())['command']
with (r/'build.log').open('xb') as f:
 p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT);(r/'child.json').write_text(json.dumps({'pid':p.pid,'start_ticks':Path('/proc',str(p.pid),'stat').read_text().split()[21]}));rc=p.wait()
(r/'finished.json').write_text(json.dumps({'exit_code':rc,'at':datetime.datetime.now().astimezone().isoformat()}))
