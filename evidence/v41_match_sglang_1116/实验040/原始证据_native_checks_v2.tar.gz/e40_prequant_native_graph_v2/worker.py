from pathlib import Path
import subprocess,datetime,json,resource
resource.setrlimit(resource.RLIMIT_CORE,(0,0));r=Path('/expt/diagnostics/e40_prequant_native_graph_v2')
with (r/'probe.log').open('xb') as f:
 p=subprocess.Popen(['/opt/venv/bin/python3',str(r/'probe.py')],stdout=f,stderr=subprocess.STDOUT);(r/'child.json').write_text(json.dumps({'pid':p.pid,'start_ticks':Path('/proc',str(p.pid),'stat').read_text().split()[21]}));rc=p.wait()
(r/'finished.json').write_text(json.dumps({'exit_code':rc,'at':datetime.datetime.now().astimezone().isoformat()}))
