from pathlib import Path
import json,subprocess,os,datetime,resource
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
r=Path('/expt/diagnostics/e43_h64_sparse_checks_v1');env=dict(os.environ,MUSA_VISIBLE_DEVICES='0',LD_PRELOAD='',OMP_NUM_THREADS='1',PYTHONPATH='/expt/builds/native_sg438_control/native_checks_v8',LD_LIBRARY_PATH='/opt/venv/lib/python3.10/site-packages/tilelang/lib:/expt/artifacts/native_sg438_control_v1/lib/runtime:/opt/venv/lib/python3.10/site-packages/torch_musa/lib:/opt/venv/lib/python3.10/site-packages/torch/lib:/opt/venv/lib/python3.10/site-packages/tvm_ffi/lib:/usr/local/musa/lib')
common=['--module','musa_python_kernel_test_module'];h64='/expt/artifacts/e43_sparse_h64_sg438_v1/libdeepseek_v41_sparse_h64_bf16.so';commands=[['/opt/venv/bin/python3',str(r/'src/tools/musa_deepseek_v41/validate_sparse_library_pair.py'),'--h8','/expt/artifacts/native_sg438_control_v1/lib/sparse/libdeepseek_v41_sparse_h8_bf16.so','--h64',h64,'--output',str(r/'pair_result.json')]+common,['/opt/venv/bin/python3',str(r/'src/tools/musa_deepseek_v41/validate_native_sparse_mate.py'),'--library',h64,'--heads','64','--graph','--output',str(r/'h64_result.json')]+common]
(r/'commands.json').write_text(json.dumps(commands,indent=2));codes=[]
for i,cmd in enumerate(commands):
 with (r/(str(i)+'.log')).open('xb') as f:
  p=subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT);(r/'child.json').write_text(json.dumps({'pid':p.pid,'start_ticks':Path('/proc',str(p.pid),'stat').read_text().split()[21],'command':cmd}));code=p.wait()
 codes.append(code)
 if code:break
(r/'finished.json').write_text(json.dumps({'exit_codes':codes,'all_pass':codes==[0,0],'at':datetime.datetime.now().astimezone().isoformat()}))
