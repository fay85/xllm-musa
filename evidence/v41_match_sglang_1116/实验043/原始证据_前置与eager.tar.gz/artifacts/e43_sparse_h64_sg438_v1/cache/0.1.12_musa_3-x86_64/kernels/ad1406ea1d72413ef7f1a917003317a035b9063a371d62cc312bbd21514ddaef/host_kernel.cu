// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* __tvm_musa_robust_descriptor_create_packed = NULL;
static void* __tvm_tensormap_create_tiled_packed = NULL;
static void* dsa_prefill_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t dsa_prefill(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t dsa_prefill(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[22];
  void* stack_ffi_any = stack;
  if (!((num_args == 9))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "dsa_prefill: num_args should be 9", (long long)(num_args), (long long)(9));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "dsa_prefill: args pointer is NULL");
    return -1;
  }
  int32_t q_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((q_handle_type_index == 0) || (q_handle_type_index == 4)) || (q_handle_type_index == 7)) || (64 <= q_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input q expected pointer or tensor handle");
    return -1;
  }
  int32_t kv_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((kv_handle_type_index == 0) || (kv_handle_type_index == 4)) || (kv_handle_type_index == 7)) || (64 <= kv_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input kv expected pointer or tensor handle");
    return -1;
  }
  int32_t indices_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((indices_handle_type_index == 0) || (indices_handle_type_index == 4)) || (indices_handle_type_index == 7)) || (64 <= indices_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input indices expected pointer or tensor handle");
    return -1;
  }
  int32_t output_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((output_handle_type_index == 0) || (output_handle_type_index == 4)) || (output_handle_type_index == 7)) || (64 <= output_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input output expected pointer or tensor handle");
    return -1;
  }
  int32_t max_logits_out_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((max_logits_out_handle_type_index == 0) || (max_logits_out_handle_type_index == 4)) || (max_logits_out_handle_type_index == 7)) || (64 <= max_logits_out_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input max_logits_out expected pointer or tensor handle");
    return -1;
  }
  int32_t lse_handle_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((((lse_handle_type_index == 0) || (lse_handle_type_index == 4)) || (lse_handle_type_index == 7)) || (64 <= lse_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input lse expected pointer or tensor handle");
    return -1;
  }
  int32_t attn_sink_handle_type_index = (((TVMFFIAny*)args)[6].type_index);
  if (!(((((attn_sink_handle_type_index == 0) || (attn_sink_handle_type_index == 4)) || (attn_sink_handle_type_index == 7)) || (64 <= attn_sink_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input attn_sink expected pointer or tensor handle");
    return -1;
  }
  int32_t sm_scale_type_index = (((TVMFFIAny*)args)[7].type_index);
  if (!((((sm_scale_type_index == 3) || (sm_scale_type_index == 1)) || (sm_scale_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill scalar sm_scale expected float");
    return -1;
  }
  int32_t persistent_blocks_type_index = (((TVMFFIAny*)args)[8].type_index);
  if (!(((persistent_blocks_type_index == 1) || (persistent_blocks_type_index == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill scalar persistent_blocks expected integer");
    return -1;
  }
  void* q_handle = ((q_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* kv_handle = ((kv_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* indices_handle = ((indices_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* output_handle = ((output_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* max_logits_out_handle = ((max_logits_out_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  void* lse_handle = ((lse_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[5].v_ptr) + 24)) : (((TVMFFIAny*)args)[5].v_ptr));
  void* attn_sink_handle = ((attn_sink_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[6].v_ptr) + 24)) : (((TVMFFIAny*)args)[6].v_ptr));
  float sm_scale = ((sm_scale_type_index == 3) ? ((float)(((TVMFFIAny*)args)[7].v_float64)) : ((float)(((TVMFFIAny*)args)[7].v_int64)));
  int32_t persistent_blocks = ((int32_t)(((TVMFFIAny*)args)[8].v_int64));
  bool dsa_prefill_q_is_null = (q_handle == NULL);
  if (!(!dsa_prefill_q_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "dsa_prefill.q is expected to have non-NULL pointer");
    return -1;
  }
  bool dsa_prefill_kv_is_null = (kv_handle == NULL);
  if (!(!dsa_prefill_kv_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "dsa_prefill.kv is expected to have non-NULL pointer");
    return -1;
  }
  bool dsa_prefill_indices_is_null = (indices_handle == NULL);
  if (!(!dsa_prefill_indices_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "dsa_prefill.indices is expected to have non-NULL pointer");
    return -1;
  }
  bool dsa_prefill_output_is_null = (output_handle == NULL);
  if (!(!dsa_prefill_output_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "dsa_prefill.output is expected to have non-NULL pointer");
    return -1;
  }
  bool dsa_prefill_max_logits_out_is_null = (max_logits_out_handle == NULL);
  if (!(!dsa_prefill_max_logits_out_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "dsa_prefill.max_logits_out is expected to have non-NULL pointer");
    return -1;
  }
  bool dsa_prefill_lse_is_null = (lse_handle == NULL);
  if (!(!dsa_prefill_lse_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "dsa_prefill.lse is expected to have non-NULL pointer");
    return -1;
  }
  bool dsa_prefill_attn_sink_is_null = (attn_sink_handle == NULL);
  if (!(!dsa_prefill_attn_sink_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "dsa_prefill.attn_sink is expected to have non-NULL pointer");
    return -1;
  }
  void* dsa_prefill_q_shape = (((DLTensor*)q_handle)[0].shape);
  void* dsa_prefill_kv_shape = (((DLTensor*)kv_handle)[0].shape);
  void* dsa_prefill_indices_shape = (((DLTensor*)indices_handle)[0].shape);
  void* dsa_prefill_output_shape = (((DLTensor*)output_handle)[0].shape);
  void* dsa_prefill_max_logits_out_shape = (((DLTensor*)max_logits_out_handle)[0].shape);
  void* dsa_prefill_lse_shape = (((DLTensor*)lse_handle)[0].shape);
  void* dsa_prefill_attn_sink_shape = (((DLTensor*)attn_sink_handle)[0].shape);
  if (!(((((DLTensor*)q_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input q ndim mismatch, expected 3", (long long)((((DLTensor*)q_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable launch_blocks requires at least one non-null buffer among: dsa_prefill.q, dsa_prefill.indices, dsa_prefill.output, dsa_prefill.max_logits_out, dsa_prefill.lse");
    return -1;
  }
  int32_t launch_blocks = ((int32_t)((int64_t*)dsa_prefill_q_shape)[0]);
  void* dsa_prefill_q_strides = (((DLTensor*)q_handle)[0].strides);
  int32_t condval;
  if ((dsa_prefill_q_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)dsa_prefill_q_strides)[1]);
  }
  int32_t q_stride_h = condval;
  int32_t condval_1;
  if ((dsa_prefill_q_strides == NULL)) {
    condval_1 = 1;
  } else {
    condval_1 = ((int32_t)((int64_t*)dsa_prefill_q_strides)[0]);
  }
  int32_t q_stride_s = condval_1;
  int32_t dev_id = (((DLTensor*)q_handle)[0].device.device_id);
  void* q = (((DLTensor*)q_handle)[0].data);
  if (!(((((DLTensor*)kv_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input kv ndim mismatch, expected 3", (long long)((((DLTensor*)kv_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t seq_len_kv = ((int32_t)((int64_t*)dsa_prefill_kv_shape)[0]);
  void* dsa_prefill_kv_strides = (((DLTensor*)kv_handle)[0].strides);
  int32_t condval_2;
  if ((dsa_prefill_kv_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)dsa_prefill_kv_strides)[1]);
  }
  int32_t kv_stride_g = condval_2;
  int32_t condval_3;
  if ((dsa_prefill_kv_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)dsa_prefill_kv_strides)[0]);
  }
  int32_t kv_stride_s = condval_3;
  void* kv = (((DLTensor*)kv_handle)[0].data);
  if (!(((((DLTensor*)indices_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input indices ndim mismatch, expected 3", (long long)((((DLTensor*)indices_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t topk = ((int32_t)((int64_t*)dsa_prefill_indices_shape)[2]);
  void* dsa_prefill_indices_strides = (((DLTensor*)indices_handle)[0].strides);
  int32_t condval_4;
  if ((dsa_prefill_indices_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)dsa_prefill_indices_strides)[1]);
  }
  int32_t indices_stride_g = condval_4;
  int32_t condval_5;
  if ((dsa_prefill_indices_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)dsa_prefill_indices_strides)[0]);
  }
  int32_t indices_stride_s = condval_5;
  void* indices = (((DLTensor*)indices_handle)[0].data);
  if (!(((((DLTensor*)output_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input output ndim mismatch, expected 3", (long long)((((DLTensor*)output_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* dsa_prefill_output_strides = (((DLTensor*)output_handle)[0].strides);
  void* output = (((DLTensor*)output_handle)[0].data);
  if (!(((((DLTensor*)max_logits_out_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input max_logits_out ndim mismatch, expected 2", (long long)((((DLTensor*)max_logits_out_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* dsa_prefill_max_logits_out_strides = (((DLTensor*)max_logits_out_handle)[0].strides);
  void* max_logits_out = (((DLTensor*)max_logits_out_handle)[0].data);
  if (!(((((DLTensor*)lse_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input lse ndim mismatch, expected 2", (long long)((((DLTensor*)lse_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* dsa_prefill_lse_strides = (((DLTensor*)lse_handle)[0].strides);
  void* lse = (((DLTensor*)lse_handle)[0].data);
  if (!(((((DLTensor*)attn_sink_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input attn_sink ndim mismatch, expected 1", (long long)((((DLTensor*)attn_sink_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* dsa_prefill_attn_sink_strides = (((DLTensor*)attn_sink_handle)[0].strides);
  void* attn_sink = (((DLTensor*)attn_sink_handle)[0].data);
  if (!(((((((DLTensor*)q_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)q_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)q_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input q dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)dsa_prefill_q_shape)[1]) == 64))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input q shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dsa_prefill_q_shape)[1])), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)dsa_prefill_q_shape)[2]) == 512))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input q shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dsa_prefill_q_shape)[2])), (long long)(512));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_6;
  if ((dsa_prefill_q_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)dsa_prefill_q_strides)[2]);
  }
  if (!((condval_6 == 1))) {
    int32_t condval_7;
    if ((dsa_prefill_q_strides == NULL)) {
      condval_7 = 1;
    } else {
      condval_7 = ((int32_t)((int64_t*)dsa_prefill_q_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input q strides[2] violates packed ABI constraint", (long long)(condval_7), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)q_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input q byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)q_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)q_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input q device_type mismatch, expected musa", (long long)((((DLTensor*)q_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((launch_blocks == 0) || !(q == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input q data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)kv_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)kv_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)kv_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input kv dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)dsa_prefill_kv_shape)[1]) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input kv shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dsa_prefill_kv_shape)[1])), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)dsa_prefill_kv_shape)[2]) == 512))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input kv shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dsa_prefill_kv_shape)[2])), (long long)(512));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_8;
  if ((dsa_prefill_kv_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)dsa_prefill_kv_strides)[2]);
  }
  if (!((condval_8 == 1))) {
    int32_t condval_9;
    if ((dsa_prefill_kv_strides == NULL)) {
      condval_9 = 1;
    } else {
      condval_9 = ((int32_t)((int64_t*)dsa_prefill_kv_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input kv strides[2] violates packed ABI constraint", (long long)(condval_9), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)kv_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input kv byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)kv_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)kv_handle)[0].device.device_id) == (((DLTensor*)q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input kv device_id violates packed ABI constraint", (long long)((((DLTensor*)kv_handle)[0].device.device_id)), (long long)((((DLTensor*)q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)kv_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input kv device_type mismatch, expected musa", (long long)((((DLTensor*)kv_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq_len_kv == 0) || !(kv == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input kv data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)indices_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)indices_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)indices_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input indices dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)dsa_prefill_q_shape)[0]) == ((int32_t)((int64_t*)dsa_prefill_indices_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input indices shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dsa_prefill_q_shape)[0])), (long long)(((int32_t)((int64_t*)dsa_prefill_indices_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)dsa_prefill_indices_shape)[1]) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input indices shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dsa_prefill_indices_shape)[1])), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_10;
  if ((dsa_prefill_indices_strides == NULL)) {
    condval_10 = 1;
  } else {
    condval_10 = ((int32_t)((int64_t*)dsa_prefill_indices_strides)[2]);
  }
  if (!(((condval_10 == 1) || (topk == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input indices strides[2] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)indices_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input indices byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)indices_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)indices_handle)[0].device.device_id) == (((DLTensor*)q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input indices device_id violates packed ABI constraint", (long long)((((DLTensor*)indices_handle)[0].device.device_id)), (long long)((((DLTensor*)q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)indices_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input indices device_type mismatch, expected musa", (long long)((((DLTensor*)indices_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((launch_blocks == 0) || (topk == 0)) || !(indices == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input indices data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)output_handle)[0].dtype.code) == (uint8_t)4) && ((((DLTensor*)output_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)output_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input output dtype mismatch, expected bfloat16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)dsa_prefill_q_shape)[0]) == ((int32_t)((int64_t*)dsa_prefill_output_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input output shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dsa_prefill_q_shape)[0])), (long long)(((int32_t)((int64_t*)dsa_prefill_output_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)dsa_prefill_output_shape)[1]) == 64))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input output shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dsa_prefill_output_shape)[1])), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)dsa_prefill_output_shape)[2]) == 512))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input output shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dsa_prefill_output_shape)[2])), (long long)(512));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_11;
  if ((dsa_prefill_output_strides == NULL)) {
    condval_11 = 1;
  } else {
    condval_11 = ((int32_t)((int64_t*)dsa_prefill_output_strides)[2]);
  }
  if (!((condval_11 == 1))) {
    int32_t condval_12;
    if ((dsa_prefill_output_strides == NULL)) {
      condval_12 = 1;
    } else {
      condval_12 = ((int32_t)((int64_t*)dsa_prefill_output_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input output strides[2] violates packed ABI constraint", (long long)(condval_12), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_13;
  if ((dsa_prefill_output_strides == NULL)) {
    condval_13 = 1;
  } else {
    condval_13 = ((int32_t)((int64_t*)dsa_prefill_output_strides)[1]);
  }
  if (!((condval_13 == 512))) {
    int32_t condval_14;
    if ((dsa_prefill_output_strides == NULL)) {
      condval_14 = 1;
    } else {
      condval_14 = ((int32_t)((int64_t*)dsa_prefill_output_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input output strides[1] violates packed ABI constraint", (long long)(condval_14), (long long)(512));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_15;
  if ((dsa_prefill_output_strides == NULL)) {
    condval_15 = 1;
  } else {
    condval_15 = ((int32_t)((int64_t*)dsa_prefill_output_strides)[0]);
  }
  if (!(((condval_15 == 32768) || (launch_blocks == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input output strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)output_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input output byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)output_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)output_handle)[0].device.device_id) == (((DLTensor*)q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input output device_id violates packed ABI constraint", (long long)((((DLTensor*)output_handle)[0].device.device_id)), (long long)((((DLTensor*)q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)output_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input output device_type mismatch, expected musa", (long long)((((DLTensor*)output_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((launch_blocks == 0) || !(output == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input output data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)max_logits_out_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)max_logits_out_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)max_logits_out_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input max_logits_out dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)dsa_prefill_q_shape)[0]) == ((int32_t)((int64_t*)dsa_prefill_max_logits_out_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input max_logits_out shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dsa_prefill_q_shape)[0])), (long long)(((int32_t)((int64_t*)dsa_prefill_max_logits_out_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)dsa_prefill_max_logits_out_shape)[1]) == 64))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input max_logits_out shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dsa_prefill_max_logits_out_shape)[1])), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_16;
  if ((dsa_prefill_max_logits_out_strides == NULL)) {
    condval_16 = 1;
  } else {
    condval_16 = ((int32_t)((int64_t*)dsa_prefill_max_logits_out_strides)[1]);
  }
  if (!((condval_16 == 1))) {
    int32_t condval_17;
    if ((dsa_prefill_max_logits_out_strides == NULL)) {
      condval_17 = 1;
    } else {
      condval_17 = ((int32_t)((int64_t*)dsa_prefill_max_logits_out_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input max_logits_out strides[1] violates packed ABI constraint", (long long)(condval_17), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_18;
  if ((dsa_prefill_max_logits_out_strides == NULL)) {
    condval_18 = 1;
  } else {
    condval_18 = ((int32_t)((int64_t*)dsa_prefill_max_logits_out_strides)[0]);
  }
  if (!(((condval_18 == 64) || (launch_blocks == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input max_logits_out strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)max_logits_out_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input max_logits_out byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)max_logits_out_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)max_logits_out_handle)[0].device.device_id) == (((DLTensor*)q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input max_logits_out device_id violates packed ABI constraint", (long long)((((DLTensor*)max_logits_out_handle)[0].device.device_id)), (long long)((((DLTensor*)q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)max_logits_out_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input max_logits_out device_type mismatch, expected musa", (long long)((((DLTensor*)max_logits_out_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((launch_blocks == 0) || !(max_logits_out == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input max_logits_out data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)lse_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)lse_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)lse_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input lse dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)dsa_prefill_q_shape)[0]) == ((int32_t)((int64_t*)dsa_prefill_lse_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input lse shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dsa_prefill_q_shape)[0])), (long long)(((int32_t)((int64_t*)dsa_prefill_lse_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)dsa_prefill_lse_shape)[1]) == 64))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input lse shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dsa_prefill_lse_shape)[1])), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_19;
  if ((dsa_prefill_lse_strides == NULL)) {
    condval_19 = 1;
  } else {
    condval_19 = ((int32_t)((int64_t*)dsa_prefill_lse_strides)[1]);
  }
  if (!((condval_19 == 1))) {
    int32_t condval_20;
    if ((dsa_prefill_lse_strides == NULL)) {
      condval_20 = 1;
    } else {
      condval_20 = ((int32_t)((int64_t*)dsa_prefill_lse_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input lse strides[1] violates packed ABI constraint", (long long)(condval_20), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_21;
  if ((dsa_prefill_lse_strides == NULL)) {
    condval_21 = 1;
  } else {
    condval_21 = ((int32_t)((int64_t*)dsa_prefill_lse_strides)[0]);
  }
  if (!(((condval_21 == 64) || (launch_blocks == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input lse strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)lse_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input lse byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)lse_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)lse_handle)[0].device.device_id) == (((DLTensor*)q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input lse device_id violates packed ABI constraint", (long long)((((DLTensor*)lse_handle)[0].device.device_id)), (long long)((((DLTensor*)q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)lse_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input lse device_type mismatch, expected musa", (long long)((((DLTensor*)lse_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((launch_blocks == 0) || !(lse == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input lse data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)attn_sink_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)attn_sink_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)attn_sink_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input attn_sink dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)dsa_prefill_attn_sink_shape)[0]) == 64))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input attn_sink shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dsa_prefill_attn_sink_shape)[0])), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_22;
  if ((dsa_prefill_attn_sink_strides == NULL)) {
    condval_22 = 1;
  } else {
    condval_22 = ((int32_t)((int64_t*)dsa_prefill_attn_sink_strides)[0]);
  }
  if (!((condval_22 == 1))) {
    int32_t condval_23;
    if ((dsa_prefill_attn_sink_strides == NULL)) {
      condval_23 = 1;
    } else {
      condval_23 = ((int32_t)((int64_t*)dsa_prefill_attn_sink_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input attn_sink strides[0] violates packed ABI constraint", (long long)(condval_23), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)attn_sink_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input attn_sink byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)attn_sink_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)attn_sink_handle)[0].device.device_id) == (((DLTensor*)q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input attn_sink device_id violates packed ABI constraint", (long long)((((DLTensor*)attn_sink_handle)[0].device.device_id)), (long long)((((DLTensor*)q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)attn_sink_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dsa_prefill input attn_sink device_type mismatch, expected musa", (long long)((((DLTensor*)attn_sink_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(attn_sink == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dsa_prefill input attn_sink data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)12);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  result_1.v_int64;
  TL_ALIGN(128) TVMFFIAny stack_1[1];
  void* q_robust_desc_0 = stack_1;
  if (q_robust_desc_0 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = q_robust_desc_0;
  if (q == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = q;
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = ((int64_t)(((q_stride_h * 126) + (((launch_blocks - 1) * q_stride_s) * 2)) + 1024));
  (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = (int64_t)0;
  if (__tvm_musa_robust_descriptor_create_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_musa_robust_descriptor_create", &__tvm_musa_robust_descriptor_create_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_musa_robust_descriptor_create_packed, (TVMFFIAny*) stack_ffi_any, 3, &result_2) != 0) {
    return -1;
  }
  result_2.v_ptr;
  TL_ALIGN(128) TVMFFIAny stack_2[1];
  void* kv_robust_desc_1 = stack_2;
  if (kv_robust_desc_1 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = kv_robust_desc_1;
  if (kv == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = kv;
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = ((int64_t)((((seq_len_kv - 1) * kv_stride_s) * 2) + 1024));
  (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = (int64_t)0;
  if (__tvm_musa_robust_descriptor_create_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_musa_robust_descriptor_create", &__tvm_musa_robust_descriptor_create_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_3;
  result_3.type_index = kTVMFFINone;
  result_3.zero_padding = 0;
  result_3.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_musa_robust_descriptor_create_packed, (TVMFFIAny*) stack_ffi_any, 3, &result_3) != 0) {
    return -1;
  }
  result_3.v_ptr;
  TL_ALIGN(128) TVMFFIAny stack_3[16];
  void* q_desc_0 = stack_3;
  if (q_desc_0 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = q_desc_0;
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)5);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = ((int64_t)3);
  if (q == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = q;
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)(uint64_t)512);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)(uint64_t)64);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)((uint64_t)launch_blocks));
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)(uint64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = ((int64_t)((uint64_t)(((int64_t)q_stride_h) * (int64_t)2)));
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)((uint64_t)(((int64_t)q_stride_s) * (int64_t)2)));
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = ((int64_t)128);
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)64);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[14].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[14].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[15].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[15].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[15].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[16].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[16].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[16].v_int64) = ((int64_t)0);
  (((TVMFFIAny*)stack_ffi_any)[17].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[17].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[17].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[18].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[18].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[18].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[19].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[19].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[19].v_int64) = ((int64_t)0);
  (((TVMFFIAny*)stack_ffi_any)[20].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[20].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[20].v_int64) = (int64_t)0;
  if (__tvm_tensormap_create_tiled_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_tensormap_create_tiled", &__tvm_tensormap_create_tiled_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_4;
  result_4.type_index = kTVMFFINone;
  result_4.zero_padding = 0;
  result_4.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_tensormap_create_tiled_packed, (TVMFFIAny*) stack_ffi_any, 20, &result_4) != 0) {
    return -1;
  }
  result_4.v_ptr;
  if (attn_sink == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = attn_sink;
  if (indices == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = indices;
  if (kv == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = kv;
  if (kv_robust_desc_1 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = kv_robust_desc_1;
  if (lse == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = lse;
  if (max_logits_out == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_ptr) = max_logits_out;
  if (output == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_ptr) = output;
  if (q_desc_0 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_ptr) = q_desc_0;
  if (q_robust_desc_0 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_ptr) = q_robust_desc_0;
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)indices_stride_s);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = ((int64_t)kv_stride_s);
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = ((int64_t)launch_blocks);
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = ((int64_t)seq_len_kv);
  (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 3;
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_float64) = ((double)sm_scale);
  (((TVMFFIAny*)stack_ffi_any)[14].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[14].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].v_int64) = ((int64_t)topk);
  (((TVMFFIAny*)stack_ffi_any)[15].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[15].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[15].v_int64) = ((int64_t)launch_blocks);
  (((TVMFFIAny*)stack_ffi_any)[16].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[16].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[16].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[17].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[17].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[17].v_int64) = ((int64_t)640);
  (((TVMFFIAny*)stack_ffi_any)[18].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[18].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[18].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[19].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[19].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[19].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[20].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[20].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[20].v_int64) = ((int64_t)172544);
  (((TVMFFIAny*)stack_ffi_any)[21].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[21].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[21].v_int64) = (int64_t)0;
  if (dsa_prefill_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "dsa_prefill_kernel", &dsa_prefill_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_5;
  result_5.type_index = kTVMFFINone;
  result_5.zero_padding = 0;
  result_5.v_int64 = 0;
  if (TVMFFIFunctionCall(dsa_prefill_kernel_packed, (TVMFFIAny*) stack_ffi_any, 21, &result_5) != 0) {
    return -1;
  }
  result_5.v_int64;
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return dsa_prefill(self, args, num_args, result);
}
