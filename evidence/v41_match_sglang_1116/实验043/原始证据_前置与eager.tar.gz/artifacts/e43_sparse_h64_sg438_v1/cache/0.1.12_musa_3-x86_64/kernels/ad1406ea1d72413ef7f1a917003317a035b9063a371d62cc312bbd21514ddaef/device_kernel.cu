#include <tl_templates/musa/common.h>
#include <tl_templates/musa/cvt.h>
#include <tl_templates/musa/fop.h>
#include <tl_templates/musa/accelerated_ops.h>
#include <tl_templates/musa/intrin.h>
#include <tl_templates/musa/distributed.h>
#include <math_constants.h>
#include <tl_templates/musa/gemm.h>
#include <tl_templates/musa/copy.h>
#include <tl_templates/musa/barrier.h>
#include <tl_templates/musa/reduce.h>
#include <tl_templates/musa/scan.h>
#include <tl_templates/musa/threadblock_swizzle.h>
#include <tl_templates/musa/debug.h>

extern "C" __global__ void dsa_prefill_kernel(const float* __restrict__ attn_sink, const int* __restrict__ indices, const bfloat16_t* __restrict__ kv, __attribute__((grid_constant)) const tl::robust_param_desc_t kv_robust_desc_1, float* __restrict__ lse, float* __restrict__ max_logits_out, bfloat16_t* __restrict__ output, __attribute__((grid_constant)) const MUtensorDescriptor q_desc_0, __attribute__((grid_constant)) const tl::robust_param_desc_t q_robust_desc_0, int indices_stride_s, int kv_stride_s, int launch_blocks, int seq_len_kv, float sm_scale, int topk);
extern "C" __global__ void __launch_bounds__(640, 1) dsa_prefill_kernel(const float* __restrict__ attn_sink, const int* __restrict__ indices, const bfloat16_t* __restrict__ kv, __attribute__((grid_constant)) const tl::robust_param_desc_t kv_robust_desc_1, float* __restrict__ lse, float* __restrict__ max_logits_out, bfloat16_t* __restrict__ output, __attribute__((grid_constant)) const MUtensorDescriptor q_desc_0, __attribute__((grid_constant)) const tl::robust_param_desc_t q_robust_desc_0, int indices_stride_s, int kv_stride_s, int launch_blocks, int seq_len_kv, float sm_scale, int topk) {
  __musa_async_bar_record(18);
  extern __shared__ __align__(4096) uchar buf_dyn_shmem[];
  void* kv_shared = ((void*)((char*)buf_dyn_shmem + 0));
  void* q_shared = ((void*)((char*)buf_dyn_shmem + 65536));
  void* v_shared_0 = ((void*)((char*)buf_dyn_shmem + 131072));
  void* v_shared_1 = ((void*)((char*)buf_dyn_shmem + 147456));
  void* scores_shared = ((void*)((char*)buf_dyn_shmem + 163840));
  void* alpha_shared = ((void*)((char*)buf_dyn_shmem + 172032));
  void* sum_exp_inv_shared = ((void*)((char*)buf_dyn_shmem + 172288));
  int phase_count[1];
  int logical_phase[1];
  int logical_bx = 0;
  int dynamic_total_blocks = 0;
  float sumexp[2];
  float m_i[2];
  float acc_o_l_0[32];
  float acc_o_l_1[32];
  __shared__ signed char is_kv_valid[64];
  float sumexp_inv[2];
  float max_logits[2];
  float acc_o_r_0[32];
  float acc_o_r_1[32];
  int topk_len_local[1];
  int kperm_indices_local[4];
  signed char kperm_mask_local[4];
  float acc_s[16];
  bfloat16_t kv_reg_l[64];
  float m_i_prev[2];
  float m_i_clear[2];
  float alpha_local[2];
  bfloat16_t acc_s_cast[16];
  float sumexp_i[2];
  bfloat16_t kv_reg_r[64];
  float alpha_r[2];
  if (tl::tl_shuffle_elect<0>()) {
    __musa_async_init_arrival(1, ((128 + 31) / 32), 0);
    __musa_async_init_arrival(2, ((256 + 31) / 32), 0);
    __musa_async_init_arrival(3, ((128 + 31) / 32), 0);
    __musa_async_init_arrival(4, ((128 + 31) / 32), 0);
    __musa_async_init_arrival(5, ((256 + 31) / 32), 0);
    __musa_async_init_arrival(6, ((256 + 31) / 32), 0);
    __musa_async_init_arrival(7, ((512 + 31) / 32), 0);
    __musa_async_init_arrival(8, ((256 + 31) / 32), 0);
    __musa_async_init_arrival(9, ((256 + 31) / 32), 0);
    __musa_async_init_arrival(10, ((256 + 31) / 32), 0);
    __musa_async_init_arrival(11, ((256 + 31) / 32), 0);
    __musa_async_init_arrival(12, ((256 + 31) / 32), 0);
    __musa_async_init_arrival(13, ((256 + 31) / 32), 0);
    __musa_async_init_arrival(14, ((256 + 31) / 32), 0);
    __musa_async_init_arrival(15, ((256 + 31) / 32), 0);
    __musa_async_init_arrival(16, ((256 + 31) / 32), 0);
    __musa_async_init_arrival(17, ((256 + 31) / 32), 0);
    __musa_async_init_arrival(18, ((128 + 31) / 32), 0);
  }
  tl::fence_barrier_init();
  __syncthreads_lm();
  __syncthreads_lm();
  phase_count[0] = 0;
  logical_phase[0] = 0;
  logical_bx = ((int)blockIdx.x);
  if ((512 <= ((int)threadIdx.x)) && (logical_bx < launch_blocks)) {
    if (((int)threadIdx.x) == 512) {
      #pragma unroll
      for (int panel = 0; panel < 4; ++panel) {
        __musa_async_add_trans(1, 16384);
        tl::tma_load<SmemSwizzleGranularity::B16, SmemSwizzleStride::B256, SmemSwizzleLine::B256, CacheHint::CACHE_NORMAL, CacheHint::CACHE_NORMAL>(q_desc_0, 1, (&(((bfloat16_t*)q_shared)[(panel * 8192)])), (panel * 128), 0, logical_bx, 128, 64, 1);
      }
    }
    __musa_async_arrive(1);
  }
  if ((256 <= ((int)threadIdx.x)) && (((int)threadIdx.x) < 512)) {
    __musa_async_arrive(13);
    __musa_async_arrive(14);
  }
  while (1) {
    if (!((logical_bx < launch_blocks))) { break; }
    int s_i = logical_bx;
    dynamic_total_blocks = ((topk + 63) >> 6);
    if (((int)threadIdx.x) < 256) {
      float broadcast_var = 0x0p+0f/*0.000000e+00*/;
      *(tl_f2*)(sumexp + 0) = (tl_f2{static_cast<float>(broadcast_var), static_cast<float>(broadcast_var)});
      float broadcast_var_1 = -0x1p+30f/*-1.073742e+09*/;
      *(tl_f2*)(m_i + 0) = (tl_f2{static_cast<float>(broadcast_var_1), static_cast<float>(broadcast_var_1)});
      #pragma unroll
      for (int i = 0; i < 8; ++i) {
        float broadcast_var_2 = 0x0p+0f/*0.000000e+00*/;
        *(tl_f4*)(acc_o_l_0 + (i * 4)) = (tl_f4{static_cast<float>(broadcast_var_2), static_cast<float>(broadcast_var_2), static_cast<float>(broadcast_var_2), static_cast<float>(broadcast_var_2)});
      }
      #pragma unroll
      for (int i_1 = 0; i_1 < 8; ++i_1) {
        float broadcast_var_3 = 0x0p+0f/*0.000000e+00*/;
        *(tl_f4*)(acc_o_l_1 + (i_1 * 4)) = (tl_f4{static_cast<float>(broadcast_var_3), static_cast<float>(broadcast_var_3), static_cast<float>(broadcast_var_3), static_cast<float>(broadcast_var_3)});
      }
      __musa_async_wait(1, (logical_phase[0] & 1));
      for (int i_i = 0; i_i < dynamic_total_blocks; ++i_i) {
        __musa_async_wait(3, (phase_count[0] & 1));
        #pragma unroll
        for (int i_2 = 0; i_2 < 16; ++i_2) {
          int condval;
          if (((bool)is_kv_valid[(((((int)threadIdx.x) & 7) * 8) + (i_2 & 7))])) {
            condval = 0;
          } else {
            condval = -1073741824;
          }
          acc_s[i_2] = ((float)condval);
        }
        tl::gemm_ss<64, 64, 128, 8, 1, 0, 1, 0, 128, 128, 0, 0, true, 32, 64, 64, -1>((&(((bfloat16_t*)q_shared)[0])), (&(((bfloat16_t*)kv_shared)[0])), (&(acc_s[0])), 0);
        #pragma unroll
        for (int r = 0; r < 2; ++r) {
          *(tl_bf8*)(kv_reg_l + (r * 32)) = *(tl_bf8*)(((bfloat16_t*)kv_shared) + ((((((((int)threadIdx.x) & 63) >> 3) * 1024) + (r * 512)) + ((((int)threadIdx.x) >> 6) * 128)) + (((((int)threadIdx.x) & 7) ^ (((((((int)threadIdx.x) & 15) >> 3) * 8) + (r * 4)) + (((int)threadIdx.x) >> 6))) * 8)));
        }
        #pragma unroll
        for (int r_1 = 0; r_1 < 2; ++r_1) {
          *(tl_bf8*)(kv_reg_l + ((r_1 * 32) + 8)) = *(tl_bf8*)(((bfloat16_t*)kv_shared) + ((((((((int)threadIdx.x) & 63) >> 3) * 1024) + (r_1 * 512)) + ((((int)threadIdx.x) >> 6) * 128)) + ((((((int)threadIdx.x) & 7) + 8) ^ (((((((int)threadIdx.x) & 15) >> 3) * 8) + (r_1 * 4)) + (((int)threadIdx.x) >> 6))) * 8)));
        }
        tl::gemm_ss<64, 64, 128, 8, 1, 0, 1, 0, 128, 128, 0, 0, true, 32, 64, 64, -1>((&(((bfloat16_t*)q_shared)[8192])), (&(((bfloat16_t*)kv_shared)[8192])), (&(acc_s[0])), 0);
        __musa_async_wait(13, (phase_count[0] & 1));
        #pragma unroll
        for (int r_2 = 0; r_2 < 2; ++r_2) {
          *(tl_bf8*)(((bfloat16_t*)v_shared_0) + ((((r_2 * 4096) + ((((int)threadIdx.x) >> 3) * 128)) + ((((((int)threadIdx.x) & 7) >> 1) ^ ((((int)threadIdx.x) & 63) >> 3)) * 16)) + ((((int)threadIdx.x) & 1) * 8))) = *(tl_bf8*)(kv_reg_l + (r_2 * 32));
        }
        #pragma unroll
        for (int r_3 = 0; r_3 < 2; ++r_3) {
          *(tl_bf8*)(((bfloat16_t*)v_shared_0) + ((((r_3 * 4096) + ((((int)threadIdx.x) >> 3) * 128)) + (((((((int)threadIdx.x) & 7) >> 1) + 4) ^ ((((int)threadIdx.x) & 63) >> 3)) * 16)) + ((((int)threadIdx.x) & 1) * 8))) = *(tl_bf8*)(kv_reg_l + ((r_3 * 32) + 8));
        }
        #pragma unroll
        for (int r_4 = 0; r_4 < 2; ++r_4) {
          #pragma unroll
          for (int u = 0; u < 2; ++u) {
            *(tl_bf8*)(kv_reg_l + (((r_4 * 32) + (u * 8)) + 16)) = *(tl_bf8*)(((bfloat16_t*)kv_shared) + (((((((((int)threadIdx.x) & 63) >> 3) * 1024) + (r_4 * 512)) + ((((int)threadIdx.x) >> 6) * 128)) + ((((u * 8) + (((int)threadIdx.x) & 7)) ^ (((((((int)threadIdx.x) & 15) >> 3) * 8) + (r_4 * 4)) + (((int)threadIdx.x) >> 6))) * 8)) + 8192));
          }
        }
        tl::warpgroup_commit_batch();
        tl::warpgroup_wait<0>();
        tl::lma_wait();
        __musa_async_arrive(6);
        __musa_async_wait(4, (phase_count[0] & 1));
        __musa_async_arrive(5);
        tl::gemm_ss<64, 64, 128, 8, 1, 0, 1, 0, 128, 128, 0, 0, true, 32, 64, 64, -1>((&(((bfloat16_t*)q_shared)[16384])), (&(((bfloat16_t*)kv_shared)[16384])), (&(acc_s[0])), 0);
        __musa_async_wait(14, (phase_count[0] & 1));
        *(tl_bf8*)(((bfloat16_t*)v_shared_1) + ((((((int)threadIdx.x) >> 3) * 128) + ((((((int)threadIdx.x) & 7) >> 1) ^ ((((int)threadIdx.x) & 63) >> 3)) * 16)) + ((((int)threadIdx.x) & 1) * 8))) = *(tl_bf8*)(kv_reg_l + 16);
        tl::gemm_ss<64, 64, 128, 8, 1, 0, 1, 0, 128, 128, 0, 0, true, 32, 64, 64, -1>((&(((bfloat16_t*)q_shared)[24576])), (&(((bfloat16_t*)kv_shared)[24576])), (&(acc_s[0])), 0);
        *(tl_bf8*)(((bfloat16_t*)v_shared_1) + ((((((int)threadIdx.x) >> 3) * 128) + (((((((int)threadIdx.x) & 7) >> 1) + 4) ^ ((((int)threadIdx.x) & 63) >> 3)) * 16)) + ((((int)threadIdx.x) & 1) * 8))) = *(tl_bf8*)(kv_reg_l + 24);
        #pragma unroll
        for (int u_1 = 0; u_1 < 2; ++u_1) {
          *(tl_bf8*)(((bfloat16_t*)v_shared_1) + (((((((int)threadIdx.x) >> 3) * 128) + ((((u_1 * 4) + ((((int)threadIdx.x) & 7) >> 1)) ^ ((((int)threadIdx.x) & 63) >> 3)) * 16)) + ((((int)threadIdx.x) & 1) * 8)) + 4096)) = *(tl_bf8*)(kv_reg_l + ((u_1 * 8) + 48));
        }
        tl::warpgroup_commit_batch();
        tl::lma_wait();
        __musa_async_arrive(8);
        *(tl_f2*)(m_i_prev + 0) = *(tl_f2*)(m_i + 0);
        tl::warpgroup_wait<0>();
        __musa_async_arrive(7);
        #pragma unroll
        for (int i_3 = 0; i_3 < 2; ++i_3) {
          tl_f4 v_ = *(tl_f4*)(acc_s + (i_3 * 8));
          tl_f4 v__1 = *(tl_f4*)(acc_s + ((i_3 * 8) + 4));
          tl_f4 vec4 = tl::vec_max_f4(v_, v__1);
          tl_f2 v__2 = make_tl_f2((vec4)[0], (vec4)[1]);
          tl_f2 v__3 = make_tl_f2((vec4)[2], (vec4)[3]);
          tl_f2 vec2 = tl::vec_max_f2(v__2, v__3);
          float group_reduce = max((tl::vec_max_f2(v__2, v__3))[0], (tl::vec_max_f2(v__2, v__3))[1]);
          m_i_clear[i_3] = max((tl::vec_max_f2(v__2, v__3))[0], (tl::vec_max_f2(v__2, v__3))[1]);
          m_i_clear[i_3] = tl::AllReduce<tl::MaxOp, 8, 1, 0>::run(m_i_clear[i_3]);
          m_i[i_3] = max(m_i[i_3], m_i_clear[i_3]);
        }
        #pragma unroll
        for (int i_4 = 0; i_4 < 2; ++i_4) {
          m_i[i_4] = max(m_i_prev[i_4], m_i[i_4]);
        }
        tl_f2 v__4 = tl::mul2(tl::sub2(*(tl_f2*)(m_i_prev + 0), *(tl_f2*)(m_i + 0)), sm_scale);
        *(tl_f2*)(alpha_local + 0) = tl::vec_exp2_f2(v__4);
        #pragma unroll
        for (int i_5 = 0; i_5 < 4; ++i_5) {
          tl_f4 v__5 = tl::sub4(tl::mul4(*(tl_f4*)(acc_s + (i_5 * 4)), sm_scale), (tl_f4{static_cast<float>((m_i[(i_5 >> 1)] * sm_scale)), static_cast<float>((m_i[(i_5 >> 1)] * sm_scale)), static_cast<float>((m_i[(i_5 >> 1)] * sm_scale)), static_cast<float>((m_i[(i_5 >> 1)] * sm_scale))}));
          *(tl_f4*)(acc_s + (i_5 * 4)) = tl::vec_exp2_f4(v__5);
        }
        if ((((int)threadIdx.x) % 8) == 0) {
          #pragma unroll
          for (int i_6 = 0; i_6 < 2; ++i_6) {
            ((float*)alpha_shared)[((((((int)threadIdx.x) >> 7) * 32) + (i_6 * 16)) + ((((int)threadIdx.x) & 127) >> 3))] = alpha_local[i_6];
          }
        }
        #pragma unroll
        for (int i_7 = 0; i_7 < 4; ++i_7) {
          tl_bf4 __1;
          tl_f4 v__6 = *(tl_f4*)(acc_s + (i_7 * 4));
          (reinterpret_cast<tl::bfloat164_t*>(&__1))[0] = tl::cvt_float_to_bfloat16_x4(((float4*)(&v__6))[0]);
          *(tl_bf4*)(acc_s_cast + (i_7 * 4)) = __1;
        }
        #pragma unroll
        for (int i_8 = 0; i_8 < 2; ++i_8) {
          *(tl_bf8*)(((bfloat16_t*)scores_shared) + (((((((int)threadIdx.x) >> 7) * 2048) + (i_8 * 1024)) + (((((int)threadIdx.x) & 127) >> 4) * 128)) + (((((int)threadIdx.x) & 15) ^ ((i_8 * 8) + ((((int)threadIdx.x) & 127) >> 4))) * 8))) = *(tl_bf8*)(acc_s_cast + (i_8 * 8));
        }
        tl::lma_wait();
        #pragma unroll
        for (int i_9 = 0; i_9 < 8; ++i_9) {
          *(tl_f4*)(acc_o_l_0 + (i_9 * 4)) = tl::mul4(*(tl_f4*)(acc_o_l_0 + (i_9 * 4)), alpha_local[(i_9 >> 2)]);
        }
        __musa_async_wait(8, (phase_count[0] & 1));
        tl::gemm_ss<64, 128, 64, 8, 1, 0, 0, 0, 64, 128, 0, 0, true, 32, 128, 64, -1>((&(((bfloat16_t*)scores_shared)[0])), (&(((bfloat16_t*)v_shared_0)[0])), (&(acc_o_l_0[0])), 0);
        tl::warpgroup_commit_batch();
        __musa_async_arrive(15);
        #pragma unroll
        for (int i_10 = 0; i_10 < 8; ++i_10) {
          *(tl_f4*)(acc_o_l_1 + (i_10 * 4)) = tl::mul4(*(tl_f4*)(acc_o_l_1 + (i_10 * 4)), alpha_local[(i_10 >> 2)]);
        }
        #pragma unroll
        for (int i_11 = 0; i_11 < 2; ++i_11) {
          tl_f4 v__7 = *(tl_f4*)(acc_s + (i_11 * 8));
          tl_f4 v__8 = *(tl_f4*)(acc_s + ((i_11 * 8) + 4));
          tl_f4 vec4_1 = tl::vec_sum_f4(v__7, v__8);
          tl_f2 v__9 = make_tl_f2((vec4_1)[0], (vec4_1)[1]);
          tl_f2 v__10 = make_tl_f2((vec4_1)[2], (vec4_1)[3]);
          tl_f2 vec2_1 = tl::vec_sum_f2(v__9, v__10);
          float group_reduce_1 = ((tl::vec_sum_f2(v__9, v__10))[0] + (tl::vec_sum_f2(v__9, v__10))[1]);
          sumexp_i[i_11] = ((tl::vec_sum_f2(v__9, v__10))[0] + (tl::vec_sum_f2(v__9, v__10))[1]);
        }
        #pragma unroll
        for (int offset_step = 0; offset_step < 3; ++offset_step) {
          tl_f2 local_vec = *(tl_f2*)(sumexp_i + 0);
          uint v__11 = (uint)4294967295;
          int v__12 = 8 >> (offset_step + 1);
          tl_f2 other_vec = tl::shfl_xor_sync(v__11, local_vec, v__12);
          tl_f2 v__13 = tl::shfl_xor_sync(v__11, local_vec, v__12);
          *(tl_f2*)(sumexp_i + 0) = tl::vec_sum_f2(local_vec, v__13);
        }
        #pragma unroll
        for (int i_12 = 0; i_12 < 2; ++i_12) {
          sumexp[i_12] = ((sumexp[i_12] * alpha_local[i_12]) + sumexp_i[i_12]);
        }
        tl::warpgroup_wait<0>();
        __musa_async_arrive(11);
        tl::gemm_ss<64, 128, 64, 8, 1, 0, 0, 0, 64, 128, 0, 0, true, 32, 128, 64, -1>((&(((bfloat16_t*)scores_shared)[0])), (&(((bfloat16_t*)v_shared_1)[0])), (&(acc_o_l_1[0])), 0);
        tl::warpgroup_commit_batch();
        tl::warpgroup_wait<0>();
        __musa_async_arrive(12);
        phase_count[0] = (phase_count[0] ^ 1);
      }
      __musa_async_arrive(2);
      __musa_async_wait(17, ((logical_phase[0] & 1) ^ 1));
      #pragma unroll
      for (int i_13 = 0; i_13 < 2; ++i_13) {
        if (-0x1p+29f/*-5.368709e+08*/ < m_i[i_13]) {
          sumexp_inv[i_13] = (0x1p+0f/*1.000000e+00*/ / (sumexp[i_13] + exp2f(((attn_sink[((((((int)threadIdx.x) >> 7) * 32) + (i_13 * 16)) + ((((int)threadIdx.x) & 127) >> 3))] * 0x1.71547652b82fep+0f/*1.442695e+00*/) - (m_i[i_13] * sm_scale)))));
          max_logits[i_13] = ((m_i[i_13] * sm_scale) * 0x1.62e42fefa39efp-1f/*6.931472e-01*/);
          sumexp[i_13] = (log2f(sumexp[i_13]) + (m_i[i_13] * sm_scale));
        } else {
          sumexp_inv[i_13] = 0x0p+0f/*0.000000e+00*/;
          max_logits[i_13] = -MUSART_INF_F;
          sumexp[i_13] = MUSART_INF_F;
        }
        ((float*)sum_exp_inv_shared)[((((((int)threadIdx.x) >> 7) * 32) + (i_13 * 16)) + ((((int)threadIdx.x) & 127) >> 3))] = sumexp_inv[i_13];
      }
      __musa_async_arrive(16);
      #pragma unroll
      for (int i_14 = 0; i_14 < 32; ++i_14) {
        acc_o_l_0[i_14] = (acc_o_l_0[i_14] * sumexp_inv[(i_14 >> 4)]);
        acc_o_l_1[i_14] = (acc_o_l_1[i_14] * sumexp_inv[(i_14 >> 4)]);
      }
      #pragma unroll
      for (int i_15 = 0; i_15 < 32; ++i_15) {
        output[((((((s_i * 32768) + ((((int)threadIdx.x) >> 7) * 16384)) + ((i_15 >> 4) * 8192)) + (((((int)threadIdx.x) & 127) >> 3) * 512)) + ((i_15 & 15) * 8)) + (((int)threadIdx.x) & 7))] = ((bfloat16_t)acc_o_l_0[i_15]);
      }
      #pragma unroll
      for (int i_16 = 0; i_16 < 32; ++i_16) {
        output[(((((((s_i * 32768) + ((((int)threadIdx.x) >> 7) * 16384)) + ((i_16 >> 4) * 8192)) + (((((int)threadIdx.x) & 127) >> 3) * 512)) + ((i_16 & 15) * 8)) + (((int)threadIdx.x) & 7)) + 128)] = ((bfloat16_t)acc_o_l_1[i_16]);
      }
      if ((((int)threadIdx.x) % 8) == 0) {
        #pragma unroll
        for (int i_17 = 0; i_17 < 2; ++i_17) {
          max_logits_out[((((s_i * 64) + ((((int)threadIdx.x) >> 7) * 32)) + (i_17 * 16)) + ((((int)threadIdx.x) & 127) >> 3))] = max_logits[i_17];
        }
        #pragma unroll
        for (int i_18 = 0; i_18 < 2; ++i_18) {
          lse[((((s_i * 64) + ((((int)threadIdx.x) >> 7) * 32)) + (i_18 * 16)) + ((((int)threadIdx.x) & 127) >> 3))] = (sumexp[i_18] * 0x1.62e42fefa39efp-1f/*6.931472e-01*/);
        }
      }
    } else {
      if (((int)threadIdx.x) < 512) {
        #pragma unroll
        for (int i_19 = 0; i_19 < 8; ++i_19) {
          float broadcast_var_4 = 0x0p+0f/*0.000000e+00*/;
          *(tl_f4*)(acc_o_r_0 + (i_19 * 4)) = (tl_f4{static_cast<float>(broadcast_var_4), static_cast<float>(broadcast_var_4), static_cast<float>(broadcast_var_4), static_cast<float>(broadcast_var_4)});
        }
        #pragma unroll
        for (int i_20 = 0; i_20 < 8; ++i_20) {
          float broadcast_var_5 = 0x0p+0f/*0.000000e+00*/;
          *(tl_f4*)(acc_o_r_1 + (i_20 * 4)) = (tl_f4{static_cast<float>(broadcast_var_5), static_cast<float>(broadcast_var_5), static_cast<float>(broadcast_var_5), static_cast<float>(broadcast_var_5)});
        }
        __musa_async_wait(1, (logical_phase[0] & 1));
        for (int i_i_1 = 0; i_i_1 < dynamic_total_blocks; ++i_i_1) {
          __musa_async_wait(5, (phase_count[0] & 1));
          #pragma unroll
          for (int r_5 = 0; r_5 < 2; ++r_5) {
            #pragma unroll
            for (int u_2 = 0; u_2 < 2; ++u_2) {
              *(tl_bf8*)(kv_reg_r + ((r_5 * 32) + (u_2 * 8))) = *(tl_bf8*)(((bfloat16_t*)kv_shared) + (((((((((int)threadIdx.x) & 63) >> 3) * 1024) + (r_5 * 512)) + ((((int)threadIdx.x) >> 6) * 128)) + ((((u_2 * 8) + (((int)threadIdx.x) & 7)) ^ (((((((((int)threadIdx.x) & 63) >> 3) * 8) + (r_5 * 4)) + (((int)threadIdx.x) >> 6)) + 12) & 15)) * 8)) + 15872));
              *(tl_bf8*)(kv_reg_r + (((r_5 * 32) + (u_2 * 8)) + 16)) = *(tl_bf8*)(((bfloat16_t*)kv_shared) + (((((((((int)threadIdx.x) & 63) >> 3) * 1024) + (r_5 * 512)) + ((((int)threadIdx.x) >> 6) * 128)) + ((((u_2 * 8) + (((int)threadIdx.x) & 7)) ^ (((((((((int)threadIdx.x) & 63) >> 3) * 8) + (r_5 * 4)) + (((int)threadIdx.x) >> 6)) + 12) & 15)) * 8)) + 24064));
            }
          }
          tl::lma_wait();
          __musa_async_arrive(7);
          __musa_async_wait(15, (phase_count[0] & 1));
          #pragma unroll
          for (int i_21 = 0; i_21 < 2; ++i_21) {
            alpha_r[i_21] = ((float*)alpha_shared)[(((((((int)threadIdx.x) >> 7) * 32) + (i_21 * 16)) + ((((int)threadIdx.x) & 127) >> 3)) - 64)];
          }
          #pragma unroll
          for (int i_22 = 0; i_22 < 8; ++i_22) {
            *(tl_f4*)(acc_o_r_0 + (i_22 * 4)) = tl::mul4(*(tl_f4*)(acc_o_r_0 + (i_22 * 4)), alpha_r[(i_22 >> 2)]);
          }
          tl::sched_boundary();
          __musa_async_wait(11, (phase_count[0] & 1));
          #pragma unroll
          for (int r_6 = 0; r_6 < 2; ++r_6) {
            #pragma unroll
            for (int u_3 = 0; u_3 < 2; ++u_3) {
              *(tl_bf8*)(((bfloat16_t*)v_shared_0) + (((((r_6 * 4096) + ((((int)threadIdx.x) >> 3) * 128)) + ((((u_3 * 4) + ((((int)threadIdx.x) & 7) >> 1)) ^ ((((int)threadIdx.x) & 63) >> 3)) * 16)) + ((((int)threadIdx.x) & 1) * 8)) - 4096)) = *(tl_bf8*)(kv_reg_r + ((r_6 * 32) + (u_3 * 8)));
            }
          }
          tl::lma_wait();
          tl::sched_boundary();
          __musa_async_arrive(9);
          __musa_async_wait(9, (phase_count[0] & 1));
          tl::gemm_ss<64, 128, 64, 8, 1, 0, 0, 0, 64, 128, 0, 0, true, 32, 128, 64, -1>((&(((bfloat16_t*)scores_shared)[0])), (&(((bfloat16_t*)v_shared_0)[0])), (&(acc_o_r_0[0])), 256);
          tl::wait_wgmma<0>();
          __musa_async_arrive(13);
          tl::sched_boundary();
          #pragma unroll
          for (int i_23 = 0; i_23 < 8; ++i_23) {
            *(tl_f4*)(acc_o_r_1 + (i_23 * 4)) = tl::mul4(*(tl_f4*)(acc_o_r_1 + (i_23 * 4)), alpha_r[(i_23 >> 2)]);
          }
          __musa_async_wait(12, (phase_count[0] & 1));
          #pragma unroll
          for (int r_7 = 0; r_7 < 2; ++r_7) {
            #pragma unroll
            for (int u_4 = 0; u_4 < 2; ++u_4) {
              *(tl_bf8*)(((bfloat16_t*)v_shared_1) + (((((r_7 * 4096) + ((((int)threadIdx.x) >> 3) * 128)) + ((((u_4 * 4) + ((((int)threadIdx.x) & 7) >> 1)) ^ ((((int)threadIdx.x) & 63) >> 3)) * 16)) + ((((int)threadIdx.x) & 1) * 8)) - 4096)) = *(tl_bf8*)(kv_reg_r + (((r_7 * 32) + (u_4 * 8)) + 16));
            }
          }
          tl::lma_wait();
          __musa_async_arrive(10);
          __musa_async_wait(10, (phase_count[0] & 1));
          tl::gemm_ss<64, 128, 64, 8, 1, 0, 0, 0, 64, 128, 0, 0, true, 32, 128, 64, -1>((&(((bfloat16_t*)scores_shared)[0])), (&(((bfloat16_t*)v_shared_1)[0])), (&(acc_o_r_1[0])), 256);
          tl::wait_wgmma<0>();
          __musa_async_arrive(14);
          phase_count[0] = (phase_count[0] ^ 1);
        }
        __musa_async_wait(16, (logical_phase[0] & 1));
        #pragma unroll
        for (int i_24 = 0; i_24 < 8; ++i_24) {
          *(tl_f4*)(acc_o_r_0 + (i_24 * 4)) = tl::mul4(*(tl_f4*)(acc_o_r_0 + (i_24 * 4)), ((float*)sum_exp_inv_shared)[(((((((int)threadIdx.x) >> 7) * 32) + ((i_24 >> 2) * 16)) + ((((int)threadIdx.x) & 127) >> 3)) - 64)]);
          *(tl_f4*)(acc_o_r_1 + (i_24 * 4)) = tl::mul4(*(tl_f4*)(acc_o_r_1 + (i_24 * 4)), ((float*)sum_exp_inv_shared)[(((((((int)threadIdx.x) >> 7) * 32) + ((i_24 >> 2) * 16)) + ((((int)threadIdx.x) & 127) >> 3)) - 64)]);
        }
        __musa_async_arrive(17);
        #pragma unroll
        for (int i_25 = 0; i_25 < 32; ++i_25) {
          output[(((((((s_i * 32768) + ((((int)threadIdx.x) >> 7) * 16384)) + ((i_25 >> 4) * 8192)) + (((((int)threadIdx.x) & 127) >> 3) * 512)) + ((i_25 & 15) * 8)) + (((int)threadIdx.x) & 7)) - 32512)] = ((bfloat16_t)acc_o_r_0[i_25]);
        }
        #pragma unroll
        for (int i_26 = 0; i_26 < 32; ++i_26) {
          output[(((((((s_i * 32768) + ((((int)threadIdx.x) >> 7) * 16384)) + ((i_26 >> 4) * 8192)) + (((((int)threadIdx.x) & 127) >> 3) * 512)) + ((i_26 & 15) * 8)) + (((int)threadIdx.x) & 7)) - 32384)] = ((bfloat16_t)acc_o_r_1[i_26]);
        }
      } else {
        topk_len_local[0] = topk;
        if (0 < dynamic_total_blocks) {
          __musa_async_arrive(18);
          kperm_indices_local[0] = indices[((((((((int)threadIdx.x) & 63) >> 3) * 8) + (((int)threadIdx.x) >> 6)) + (s_i * indices_stride_s)) - 8)];
          kperm_indices_local[1] = indices[((((((((int)threadIdx.x) & 63) >> 3) * 8) + (((int)threadIdx.x) >> 6)) + (s_i * indices_stride_s)) - 6)];
          kperm_indices_local[2] = indices[((((((((int)threadIdx.x) & 63) >> 3) * 8) + (((int)threadIdx.x) >> 6)) + (s_i * indices_stride_s)) - 4)];
          kperm_indices_local[3] = indices[((((((((int)threadIdx.x) & 63) >> 3) * 8) + (((int)threadIdx.x) >> 6)) + (s_i * indices_stride_s)) - 2)];
          kperm_mask_local[0] = ((signed char)((((uint)kperm_indices_local[0]) < ((uint)seq_len_kv)) && (((((((int)threadIdx.x) & 63) >> 3) * 8) + (((int)threadIdx.x) >> 6)) < (topk_len_local[0] + 8))));
          int condval_1;
          if (((bool)kperm_mask_local[0])) {
            condval_1 = kperm_indices_local[0];
          } else {
            condval_1 = seq_len_kv;
          }
          kperm_indices_local[0] = condval_1;
          kperm_mask_local[1] = ((signed char)((((uint)kperm_indices_local[1]) < ((uint)seq_len_kv)) && (((((((int)threadIdx.x) & 63) >> 3) * 8) + (((int)threadIdx.x) >> 6)) < (topk_len_local[0] + 6))));
          int condval_2;
          if (((bool)kperm_mask_local[1])) {
            condval_2 = kperm_indices_local[1];
          } else {
            condval_2 = seq_len_kv;
          }
          kperm_indices_local[1] = condval_2;
          kperm_mask_local[2] = ((signed char)((((uint)kperm_indices_local[2]) < ((uint)seq_len_kv)) && (((((((int)threadIdx.x) & 63) >> 3) * 8) + (((int)threadIdx.x) >> 6)) < (topk_len_local[0] + 4))));
          int condval_3;
          if (((bool)kperm_mask_local[2])) {
            condval_3 = kperm_indices_local[2];
          } else {
            condval_3 = seq_len_kv;
          }
          kperm_indices_local[2] = condval_3;
          kperm_mask_local[3] = ((signed char)((((uint)kperm_indices_local[3]) < ((uint)seq_len_kv)) && (((((((int)threadIdx.x) & 63) >> 3) * 8) + (((int)threadIdx.x) >> 6)) < (topk_len_local[0] + 2))));
          int condval_4;
          if (((bool)kperm_mask_local[3])) {
            condval_4 = kperm_indices_local[3];
          } else {
            condval_4 = seq_len_kv;
          }
          kperm_indices_local[3] = condval_4;
          __musa_async_wait(6, ((phase_count[0] & 1) ^ 1));
          #pragma unroll
          for (int r_8 = 0; r_8 < 4; ++r_8) {
            #pragma unroll
            for (int panel_1 = 0; panel_1 < 2; ++panel_1) {
              #pragma unroll
              for (int u_5 = 0; u_5 < 2; ++u_5) {
                tl::cp_async_gs_robust<16>((&(((bfloat16_t*)kv_shared)[(((((panel_1 * 8192) + (r_8 * 2048)) + ((((int)threadIdx.x) >> 3) * 128)) + ((((u_5 * 8) + (((int)threadIdx.x) & 7)) ^ ((((int)threadIdx.x) & 127) >> 3)) * 8)) - 8192)])), (&(kv[((((panel_1 * 128) + (u_5 * 64)) + ((((int)threadIdx.x) & 7) * 8)) + (kperm_indices_local[r_8] * kv_stride_s))])), kv_robust_desc_1);
              }
            }
          }
          tl::ldlms_crossbb_commit_0();
          #pragma unroll
          for (int r_9 = 0; r_9 < 4; ++r_9) {
            is_kv_valid[((((((((int)threadIdx.x) & 63) >> 3) * 8) + (r_9 * 2)) + (((int)threadIdx.x) >> 6)) - 8)] = ((signed char)((bool)kperm_mask_local[r_9]));
          }
          tl::lma_wait();
          __musa_async_wait(7, ((phase_count[0] & 1) ^ 1));
          #pragma unroll
          for (int r_10 = 0; r_10 < 4; ++r_10) {
            #pragma unroll
            for (int panel_2 = 0; panel_2 < 2; ++panel_2) {
              #pragma unroll
              for (int u_6 = 0; u_6 < 2; ++u_6) {
                tl::cp_async_gs_robust<16>((&(((bfloat16_t*)kv_shared)[(((((panel_2 * 8192) + (r_10 * 2048)) + ((((int)threadIdx.x) >> 3) * 128)) + ((((u_6 * 8) + (((int)threadIdx.x) & 7)) ^ ((((int)threadIdx.x) & 127) >> 3)) * 8)) + 8192)])), (&(kv[(((((panel_2 * 128) + (u_6 * 64)) + ((((int)threadIdx.x) & 7) * 8)) + (kperm_indices_local[r_10] * kv_stride_s)) + 256)])), kv_robust_desc_1);
              }
            }
          }
          tl::ldlms_crossbb_commit_1();
          for (int i_i_2 = 1; i_i_2 < ((topk + 63) >> 6); ++i_i_2) {
            tl::ldlms_crossbb_wait_0();
            __musa_async_arrive(3);
            tl::ldlms_crossbb_wait_1();
            __musa_async_arrive(4);
            __musa_async_wait(18, (phase_count[0] & 1));
            phase_count[0] = (phase_count[0] ^ 1);
            __musa_async_arrive(18);
            kperm_indices_local[0] = indices[(((((i_i_2 * 64) + (((((int)threadIdx.x) & 63) >> 3) * 8)) + (((int)threadIdx.x) >> 6)) + (s_i * indices_stride_s)) - 8)];
            kperm_indices_local[1] = indices[(((((i_i_2 * 64) + (((((int)threadIdx.x) & 63) >> 3) * 8)) + (((int)threadIdx.x) >> 6)) + (s_i * indices_stride_s)) - 6)];
            kperm_indices_local[2] = indices[(((((i_i_2 * 64) + (((((int)threadIdx.x) & 63) >> 3) * 8)) + (((int)threadIdx.x) >> 6)) + (s_i * indices_stride_s)) - 4)];
            kperm_indices_local[3] = indices[(((((i_i_2 * 64) + (((((int)threadIdx.x) & 63) >> 3) * 8)) + (((int)threadIdx.x) >> 6)) + (s_i * indices_stride_s)) - 2)];
            kperm_mask_local[0] = ((signed char)((((uint)kperm_indices_local[0]) < ((uint)seq_len_kv)) && ((((i_i_2 * 64) + (((((int)threadIdx.x) & 63) >> 3) * 8)) + (((int)threadIdx.x) >> 6)) < (topk_len_local[0] + 8))));
            int condval_5;
            if (((bool)kperm_mask_local[0])) {
              condval_5 = kperm_indices_local[0];
            } else {
              condval_5 = seq_len_kv;
            }
            kperm_indices_local[0] = condval_5;
            kperm_mask_local[1] = ((signed char)((((uint)kperm_indices_local[1]) < ((uint)seq_len_kv)) && ((((i_i_2 * 64) + (((((int)threadIdx.x) & 63) >> 3) * 8)) + (((int)threadIdx.x) >> 6)) < (topk_len_local[0] + 6))));
            int condval_6;
            if (((bool)kperm_mask_local[1])) {
              condval_6 = kperm_indices_local[1];
            } else {
              condval_6 = seq_len_kv;
            }
            kperm_indices_local[1] = condval_6;
            kperm_mask_local[2] = ((signed char)((((uint)kperm_indices_local[2]) < ((uint)seq_len_kv)) && ((((i_i_2 * 64) + (((((int)threadIdx.x) & 63) >> 3) * 8)) + (((int)threadIdx.x) >> 6)) < (topk_len_local[0] + 4))));
            int condval_7;
            if (((bool)kperm_mask_local[2])) {
              condval_7 = kperm_indices_local[2];
            } else {
              condval_7 = seq_len_kv;
            }
            kperm_indices_local[2] = condval_7;
            kperm_mask_local[3] = ((signed char)((((uint)kperm_indices_local[3]) < ((uint)seq_len_kv)) && ((((i_i_2 * 64) + (((((int)threadIdx.x) & 63) >> 3) * 8)) + (((int)threadIdx.x) >> 6)) < (topk_len_local[0] + 2))));
            int condval_8;
            if (((bool)kperm_mask_local[3])) {
              condval_8 = kperm_indices_local[3];
            } else {
              condval_8 = seq_len_kv;
            }
            kperm_indices_local[3] = condval_8;
            __musa_async_wait(6, ((phase_count[0] & 1) ^ 1));
            #pragma unroll
            for (int r_11 = 0; r_11 < 4; ++r_11) {
              #pragma unroll
              for (int panel_3 = 0; panel_3 < 2; ++panel_3) {
                #pragma unroll
                for (int u_7 = 0; u_7 < 2; ++u_7) {
                  tl::cp_async_gs_robust<16>((&(((bfloat16_t*)kv_shared)[(((((panel_3 * 8192) + (r_11 * 2048)) + ((((int)threadIdx.x) >> 3) * 128)) + ((((u_7 * 8) + (((int)threadIdx.x) & 7)) ^ ((((int)threadIdx.x) & 127) >> 3)) * 8)) - 8192)])), (&(kv[((((panel_3 * 128) + (u_7 * 64)) + ((((int)threadIdx.x) & 7) * 8)) + (kperm_indices_local[r_11] * kv_stride_s))])), kv_robust_desc_1);
                }
              }
            }
            tl::ldlms_crossbb_commit_0();
            #pragma unroll
            for (int r_12 = 0; r_12 < 4; ++r_12) {
              is_kv_valid[((((((((int)threadIdx.x) & 63) >> 3) * 8) + (r_12 * 2)) + (((int)threadIdx.x) >> 6)) - 8)] = ((signed char)((bool)kperm_mask_local[r_12]));
            }
            tl::lma_wait();
            __musa_async_wait(7, ((phase_count[0] & 1) ^ 1));
            #pragma unroll
            for (int r_13 = 0; r_13 < 4; ++r_13) {
              #pragma unroll
              for (int panel_4 = 0; panel_4 < 2; ++panel_4) {
                #pragma unroll
                for (int u_8 = 0; u_8 < 2; ++u_8) {
                  tl::cp_async_gs_robust<16>((&(((bfloat16_t*)kv_shared)[(((((panel_4 * 8192) + (r_13 * 2048)) + ((((int)threadIdx.x) >> 3) * 128)) + ((((u_8 * 8) + (((int)threadIdx.x) & 7)) ^ ((((int)threadIdx.x) & 127) >> 3)) * 8)) + 8192)])), (&(kv[(((((panel_4 * 128) + (u_8 * 64)) + ((((int)threadIdx.x) & 7) * 8)) + (kperm_indices_local[r_13] * kv_stride_s)) + 256)])), kv_robust_desc_1);
                }
              }
            }
            tl::ldlms_crossbb_commit_1();
          }
          tl::ldlms_crossbb_wait_0();
          __musa_async_arrive(3);
          tl::ldlms_crossbb_wait_1();
          __musa_async_arrive(4);
          __musa_async_wait(18, (phase_count[0] & 1));
          phase_count[0] = (phase_count[0] ^ 1);
        }
      }
    }
    logical_bx = launch_blocks;
  }
}

