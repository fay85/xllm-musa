from pathlib import Path
import subprocess,json,datetime,hashlib
r=Path('/expt/builds/e43_native_ll_bootstrap_v1')
with (r/'build.log').open('xb') as f:p=subprocess.run(json.loads((r/'command.json').read_text()),stdout=f,stderr=subprocess.STDOUT)
z={'exit_code':p.returncode,'at':datetime.datetime.now().astimezone().isoformat()}
if p.returncode==0:z.update(sha256=hashlib.sha256((r/'runtime_test').read_bytes()).hexdigest(),bytes=(r/'runtime_test').stat().st_size)
(r/'finished.json').write_text(json.dumps(z,indent=2))
