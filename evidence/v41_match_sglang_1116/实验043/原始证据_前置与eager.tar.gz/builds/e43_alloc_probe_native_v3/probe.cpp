#include <pybind11/embed.h>
#include <torch/extension.h>
#include <iostream>
int main(){
 pybind11::initialize_interpreter(false);
 auto torchpy=pybind11::module_::import("torch");
 pybind11::module_::import("torch_musa").attr("set_device")(0);
 auto p=torchpy.attr("empty")(pybind11::make_tuple(1,5120),pybind11::arg("device")="musa",pybind11::arg("dtype")=torchpy.attr("bfloat16")).cast<torch::Tensor>();
 std::cout<<"pythonempty device="<<p.device()<<" keys="<<p.key_set()<<std::endl;
 auto x=torch::empty({1,5120},torch::TensorOptions().device(torch::Device(torch::kPrivateUse1,0)).dtype(torch::kBFloat16));
 std::cout<<"nativeempty device="<<x.device()<<" keys="<<x.key_set()<<std::endl;
 p.fill_(2);std::cout<<"pythonempty nativefill pass"<<std::endl;
 x.fill_(3);std::cout<<"nativeempty nativefill pass"<<std::endl;
 pybind11::module_::import("torch_musa").attr("synchronize")();
 return 0;
}