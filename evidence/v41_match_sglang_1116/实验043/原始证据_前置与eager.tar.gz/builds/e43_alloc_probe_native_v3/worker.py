from pathlib import Path
import os,json,subprocess
r=Path('/expt/builds/e43_alloc_probe_native_v3');b=Path('/workspace/xllm-mt-main/build/cmake.linux-x86_64-cpython-310');rc=0
for i,cmd in enumerate(json.loads((r/'commands.json').read_text())):
 with (r/(str(i)+'.log')).open('wb') as f:p=subprocess.run(cmd,cwd=b,env=dict(os.environ,MUSAMAPPING_PATH='/usr/local/musa/tools/musamapping'),stdout=f,stderr=subprocess.STDOUT)
 rc=p.returncode
 if rc:break
(r/'finished.json').write_text(json.dumps({'exit_code':rc}))
