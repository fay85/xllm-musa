from pathlib import Path
import subprocess,json
r=Path('/expt/builds/e43_alloc_probe_v1')
with (r/'build.log').open('wb') as f:p=subprocess.run(json.loads((r/'command.json').read_text()),stdout=f,stderr=subprocess.STDOUT)
(r/'finished.json').write_text(json.dumps({'exit_code':p.returncode}))
