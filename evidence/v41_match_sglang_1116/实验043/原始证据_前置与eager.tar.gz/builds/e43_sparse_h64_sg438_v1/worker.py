from pathlib import Path
import subprocess,os,json,datetime,hashlib
r=Path('/expt/builds/e43_sparse_h64_sg438_v1');s=Path('/workspace/xllm-mt-main');out=Path('/expt/artifacts/e43_sparse_h64_sg438_v1')
env=dict(os.environ,MATE_MUSA_ARCH_LIST='3.1',MATE_WORKSPACE_BASE=str(r/'mate_cache'),MAX_JOBS='2',MUSA_VISIBLE_DEVICES='-1',MTHREADS_VISIBLE_DEVICES='void',MUSA_HOME='/usr/local/musa',PYTHONPATH=str(s),TRITON_CACHE_DIR=str(r/'triton_cache'),LD_LIBRARY_PATH='/opt/venv/lib/python3.10/site-packages/torch_musa/lib:/opt/venv/lib/python3.10/site-packages/torch/lib:/opt/venv/lib/python3.10/site-packages/tvm_ffi/lib:/usr/local/musa/lib',PATH='/opt/venv/bin:/usr/local/musa/bin:/usr/bin:/bin')
commands=[('sparse',['python3',str(s/'tools/musa_deepseek_v41/build_sparse_mate.py'),'--donor-root','/opt/venv/lib/python3.10/site-packages','--output',str(out),'--heads','64'])]
(r/'commands.json').write_text(json.dumps(commands,indent=2));results=[]
for label,cmd in commands:
 with (r/(label+'.log')).open('wb') as f:p=subprocess.run(cmd,env=env,cwd=s,stdout=f,stderr=subprocess.STDOUT)
 result={'label':label,'exit_code':p.returncode,'at':datetime.datetime.now().astimezone().isoformat()};results.append(result);(r/(label+'_finished.json')).write_text(json.dumps(result))
 if p.returncode!=0:break
(r/'finished.json').write_text(json.dumps({'results':results,'all_pass':len(results)==1 and all(v['exit_code']==0 for v in results)},indent=2))
