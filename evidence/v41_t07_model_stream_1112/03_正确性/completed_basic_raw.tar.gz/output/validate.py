# Copyright 2026 The xLLM Authors. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
"""Actual native Torch/MATE work through the same model-stream boundary guard."""
from __future__ import annotations
import argparse
import gc
import json
from pathlib import Path
import sys
import torch
import torch_musa
from safetensors.torch import load_file
import musa_python_kernel_test_module as native
sys.path.insert(0,'/work/repos/xllm-musa')
from scripts.logger import logger


def main() -> None:
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--mhc-fixture',required=True);parser.add_argument('--mhc-directory',required=True);args=parser.parse_args();assert torch.musa.device_count()==1;torch.manual_seed(111220);torch.set_num_threads(1);device='musa:0';dtype=torch.bfloat16;rows=[]
    with torch.inference_mode():
      gate=(torch.randn(256,5120)*.02).to(device=device,dtype=dtype);up=(torch.randn(256,5120)*.02).to(device=device,dtype=dtype);down=(torch.randn(5120,256)*.02).to(device=device,dtype=dtype);mlp=native.NativeV41SharedMlp(gate,up,down,10.,True)
      for length in [1,17,256]:
       for magnitude in [0.,1.,50.]:
        x=(torch.randn(length,5120)*magnitude).to(device=device,dtype=dtype);reference=mlp.forward(x).cpu();actual=native.v41_shared_on_model_stream(x,gate,up,down,10.,True)
        consumer=actual*1.25;del actual;gc.collect();pressure=torch.empty((length*32,5120),device=device,dtype=dtype);pressure.fill_(17)
        assert torch.equal(consumer.cpu(),(reference.to(device)*1.25).cpu()),('cross-stream consumer/lifetime',length,magnitude)
        rows.append({'kind':'shared_native','rows':length,'magnitude':magnitude,'consumer_exact':True,'released_output_then_allocator_pressure':True})
      fixture=load_file(args.mhc_fixture,device='cpu');weights=[fixture['layers.0.'+name].to(device) for name in ['hc_attn_fn','hc_attn_scale','hc_attn_base']];hc=native.NativeV41HyperConnection(*weights,20,1e-6,1e-6,args.mhc_directory)
      for length in [1,17,256]:
       for magnitude in [0.,1.,50.]:
        residual=(torch.randn(length,4,5120)*magnitude).to(device=device,dtype=dtype);pre=torch.softmax(torch.randn(length,4,device=device),-1);expected=tuple(x.cpu().clone() for x in hc.prepare(residual,pre));actual=native.v41_mhc_on_model_stream(residual,pre,*weights,args.mhc_directory);copied=tuple(x.clone() for x in actual);del actual;gc.collect();torch.empty((length,4,5120),device=device,dtype=dtype).fill_(19)
        assert all(torch.equal(x.cpu(),y) for x,y in zip(copied,expected)),('MATE same stream',length,magnitude)
        rows.append({'kind':'real_mhc_MATE','rows':length,'magnitude':magnitude,'all_4_outputs_exact':True,'orig_stream_consumer_and_release':True})
    result={'status':'PASS_NATIVE_MODEL_STREAM_PRODUCER_CONSUMER_LIFETIME','cases':rows,'scope':'Uses exact production C++ boundary guard, real MATE HC weights, NativeSharedMlp, original-stream consumer and allocator pressure. Full model/multirank still needs actual service checks.','accuracy_scope':'仅通过基础功能检查，未完成模型精度验收'};args.output.write_text(json.dumps(result,indent=2));logger.info('Model-stream direct checks passed, cases=%d',len(rows))


if __name__=='__main__':main()
