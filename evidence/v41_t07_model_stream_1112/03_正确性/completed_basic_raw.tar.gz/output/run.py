import pathlib,os,subprocess,json,datetime
r=pathlib.Path('/work');o=r/'new_start_t07_model_stream_probe_v1';env=dict(os.environ);env.update(MUSA_VISIBLE_DEVICES='0',LD_PRELOAD='',PYTHONPATH='/work/artifacts/native_t07_model_stream/lib:/work/repos/xllm-musa',TVM_FFI_GPU_BACKEND='musa');env['LD_LIBRARY_PATH']='/work/artifacts/native_t07_model_stream/lib:'+env.get('LD_LIBRARY_PATH','');cfg=json.loads((r/'runs/t04_shared_tp_tp_v1/sj10/role_config.json').read_text());old=cfg['ranks'][0]['environment']
cmd=['python3',str(o/'validate.py'),'--output',str(o/'checks.json'),'--mhc-fixture','/work/correctness/fixtures/w4afp8_mt_layer0_mhc.safetensors','--mhc-directory',old['XLLM_DSV41_MATE_MHC_DIR']]
with (o/'probe.log').open('w') as log:rc=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
(o/'result.json').write_text(json.dumps({'exit_code':rc,'finished_at':datetime.datetime.now().astimezone().isoformat(),'automatic_kill':False}));raise SystemExit(rc)
