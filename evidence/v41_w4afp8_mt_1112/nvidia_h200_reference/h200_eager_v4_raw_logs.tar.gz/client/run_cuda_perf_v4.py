import pathlib,json,shutil,requests,time,subprocess,sqlite3,datetime,hashlib
r=pathlib.Path('/work');out=r/'performance/h200_eager_v4';out.mkdir(parents=True,exist_ok=False);prior=r/'performance/h200_eager_v3';gate=json.loads((prior/'basic_gate.json').read_text());assert gate['status']=='PASS_TWO_ARITHMETIC' and len(gate['answers'])==2 and all(x['passed'] for x in gate['answers']);assert json.loads((prior/'protocol.json').read_text())['status']=='TOKEN_IDENTITY_VERIFIED'
for name in ['protocol.json','answers.json','basic_gate.json','input256_output256.jsonl','input2048_output256.jsonl']:shutil.copyfile(prior/name,out/name)
(out/'resume_note.json').write_text(json.dumps({'reuses_basic_gate':str(prior/'basic_gate.json'),'same_live_model_services':True,'reason':'v3officialCLI lacked optional sse_starlette, before any measured request; installofficialperfextra inisolatedvenv and startfreshmeasurementfolders'},indent=2))
url='http://10.10.142.232:32910/v1/completions';model='deepseek-v4.1-flash-1017';results=[]
for length in [256,2048]:
 for phase,count in [('warmup',1),('measured',5)]:
  dst=out/('input'+str(length)+'_output256')/phase
  cmd=['/work/client/venv/bin/evalscope','perf','--api','openai','--model',model,'--url',url,'--dataset','line_by_line','--dataset-path',str(out/('input'+str(length)+'_output256.jsonl')),'--number',str(count),'--parallel','1','--num-workers','1','--db-commit-interval','1','--log-every-n-query','1','--warmup-num','0','--tokenizer-path','/model','--stream','--outputs-dir',str(dst),'--no-timestamp','--no-test-connection','--connect-timeout','20','--read-timeout','1800','--total-timeout','3600']
  row={'input':length,'phase':phase,'count':count,'command':cmd,'started_at':datetime.datetime.now().astimezone().isoformat()};(out/'active.json').write_text(json.dumps(row,indent=2))
  with (out/(phase+'_input'+str(length)+'.log')).open('xb') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
  row['exit']=p.returncode;row['finished_at']=datetime.datetime.now().astimezone().isoformat();results.append(row);(out/'status.json').write_text(json.dumps(results,indent=2));assert p.returncode==0
  dbs=list(dst.rglob('benchmark_data.db'));assert len(dbs)==1
  with sqlite3.connect('file:'+str(dbs[0])+'?mode=ro',uri=True) as db:rr=db.execute('select success,prompt_tokens,completion_tokens,latency,first_chunk_latency from result').fetchall()
  assert len(rr)==count and all(x[0] and x[1]==length and x[2]==256 and x[3]>x[4]>0 for x in rr),rr
  row['verified_rows']=rr;(out/'status.json').write_text(json.dumps(results,indent=2))
(out/'client_runs_finished.json').write_text(json.dumps({'status':'PASS_ALL_FOUR_PHASES_EXACT_NATIVE_TOKEN_COUNTS','finished_at':datetime.datetime.now().astimezone().isoformat()},indent=2))
